# Band&R Backend - Complete Backend API

## Project Overview
Band&R is a social platform for musicians, bands, and music fans. This is the complete Java EE backend with REST API endpoints, JWT authentication, and admin functionality.

## Features
- ✅ User Registration & Login with JWT authentication
- ✅ User Profile Management
- ✅ Band Management
- ✅ Post Creation, Likes & Saves
- ✅ Music Sample Uploads
- ✅ Messaging System
- ✅ Admin Panel (user/band/post management)
- ✅ CORS enabled for frontend integration
- ✅ BCrypt password hashing
- ✅ RESTful API endpoints

## Tech Stack
- **Java EE 7**
- **JAX-RS** (RESTful Web Services)
- **JPA/Hibernate** (Object-Relational Mapping)
- **MySQL** (Database)
- **JWT** (JSON Web Tokens for authentication)
- **BCrypt** (Password hashing)
- **Maven** (Build tool)

## Prerequisites
1. **Java Development Kit (JDK) 8** or higher
2. **Apache NetBeans** (or any Java EE IDE)
3. **GlassFish Server 4.1** or **Payara Server**
4. **MySQL Server 5.7+**
5. **Maven 3.6+**

## Database Setup

### 1. Create Database
```sql
CREATE DATABASE bandr_uj CHARACTER SET utf8 COLLATE utf8_general_ci;
```

### 2. Import Database Schema
Import the provided `bandr_uj.sql` file:
```bash
mysql -u root -p bandr_uj < bandr_uj.sql
```

### 3. Configure JDBC Connection Pool in GlassFish
1. Start GlassFish/Payara Server
2. Go to Admin Console (usually http://localhost:4848)
3. Navigate to: **Resources → JDBC → JDBC Connection Pools**
4. Create New Connection Pool:
   - **Pool Name**: `bandr_pool`
   - **Resource Type**: `javax.sql.DataSource`
   - **Database Driver Vendor**: `MySQL`
   - **Driver Classname**: `com.mysql.cj.jdbc.Driver` (MySQL 8.x) or `com.mysql.jdbc.Driver` (MySQL 5.x)
   
5. Additional Properties:
   - **serverName**: `localhost`
   - **portNumber**: `3306`
   - **databaseName**: `bandr_uj`
   - **user**: `root` (your MySQL username)
   - **password**: `` (your MySQL password)
   - **useSSL**: `false`
   - **allowPublicKeyRetrieval**: `true` (for MySQL 8.x)

6. Test the connection and save

### 4. Create JDBC Resource
1. Navigate to: **Resources → JDBC → JDBC Resources**
2. Create New JDBC Resource:
   - **JNDI Name**: `java:/bandr_uj`
   - **Pool Name**: `bandr_pool`

## Project Setup

### 1. Import Project to NetBeans
1. Open NetBeans
2. **File → Open Project**
3. Select `bandr-backend-complete` folder
4. Wait for Maven to download dependencies

### 2. Configure Server
1. Right-click on project → **Properties**
2. **Run** category → Select your GlassFish/Payara server
3. **Context Path**: `/bandr`

### 3. Build Project
```bash
mvn clean install
```

### 4. Deploy Application
1. Right-click project → **Clean and Build**
2. Right-click project → **Run**
3. Server will start and deploy the application

## API Base URL
```
http://localhost:8080/bandr/webresources
```

## API Endpoints

### Authentication Endpoints

#### Register
```http
POST /webresources/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "userType": "fan",
  "bio": "Music lover",
  "location": "New York",
  "favGenres": "Rock, Jazz",
  "instruments": "Guitar"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "userId": 1,
  "username": "johndoe",
  "email": "john@example.com",
  "userType": "fan"
}
```

#### Login
```http
POST /webresources/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "userId": 1,
  "username": "johndoe",
  "email": "john@example.com",
  "userType": "fan"
}
```

#### Get Current User
```http
GET /webresources/auth/me
Authorization: Bearer {token}
```

#### Refresh Token
```http
POST /webresources/auth/refresh
Authorization: Bearer {token}
```

#### Logout
```http
POST /webresources/auth/logout
Authorization: Bearer {token}
```

### User Endpoints

#### Get All Users
```http
GET /webresources/users
```

#### Get User by ID
```http
GET /webresources/users/{id}
```

#### Update User
```http
PUT /webresources/users/{id}
Authorization: Bearer {token}
Content-Type: application/json
```

#### Delete User
```http
DELETE /webresources/users/{id}
Authorization: Bearer {token}
```

### Profile Endpoints

#### Get Profile by User ID
```http
GET /webresources/profiles/user/{userId}
```

#### Update Profile
```http
PUT /webresources/profiles/{userId}
Authorization: Bearer {token}
Content-Type: application/json
```

### Band Endpoints

#### Get All Bands
```http
GET /webresources/bands
```

#### Get Band by ID
```http
GET /webresources/bands/{id}
```

#### Create Band
```http
POST /webresources/bands
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "The Rock Band",
  "description": "We rock!",
  "genre": "Rock"
}
```

#### Update Band
```http
PUT /webresources/bands/{id}
Authorization: Bearer {token}
```

#### Delete Band
```http
DELETE /webresources/bands/{id}
Authorization: Bearer {token}
```

### Post Endpoints

#### Get All Posts
```http
GET /webresources/posts
```

#### Get Post by ID
```http
GET /webresources/posts/{id}
```

#### Get Posts by Band
```http
GET /webresources/posts/band/{bandId}
```

#### Create Post
```http
POST /webresources/posts
Authorization: Bearer {token}
Content-Type: application/json

{
  "bandId": 1,
  "title": "New Album Release!",
  "content": "Check out our new album..."
}
```

#### Update Post
```http
PUT /webresources/posts/{id}
Authorization: Bearer {token}
```

#### Delete Post
```http
DELETE /webresources/posts/{id}
Authorization: Bearer {token}
```

### Post Likes Endpoints

#### Like/Unlike Post (Toggle)
```http
POST /webresources/postlikes/toggle
Authorization: Bearer {token}
Content-Type: application/json

{
  "postId": 1,
  "userId": 1
}
```

#### Get Likes for Post
```http
GET /webresources/postlikes/post/{postId}
```

#### Check if User Liked Post
```http
GET /webresources/postlikes/check/{postId}/{userId}
```

### Saved Posts Endpoints

#### Save/Unsave Post (Toggle)
```http
POST /webresources/savedposts/toggle
Authorization: Bearer {token}
Content-Type: application/json

{
  "userId": 1,
  "postId": 1
}
```

#### Get Saved Posts for User
```http
GET /webresources/savedposts/user/{userId}
Authorization: Bearer {token}
```

### Message Endpoints

#### Send Message
```http
POST /webresources/messages
Authorization: Bearer {token}
Content-Type: application/json

{
  "senderId": 1,
  "receiverId": 2,
  "content": "Hello!"
}
```

#### Get Messages Between Users
```http
GET /webresources/messages/between/{user1Id}/{user2Id}
Authorization: Bearer {token}
```

#### Get Inbox
```http
GET /webresources/messages/inbox/{userId}
Authorization: Bearer {token}
```

### Sample (Music) Endpoints

#### Upload Sample
```http
POST /webresources/samples
Authorization: Bearer {token}
Content-Type: application/json

{
  "bandId": 1,
  "title": "Demo Track 1",
  "fileUrl": "https://example.com/track.mp3"
}
```

#### Get Samples by Band
```http
GET /webresources/samples/band/{bandId}
```

### Admin Endpoints (Requires admin token)

#### Get All Users (Admin)
```http
GET /webresources/admin/users
Authorization: Bearer {admin_token}
```

#### Get User by ID (Admin)
```http
GET /webresources/admin/users/{id}
Authorization: Bearer {admin_token}
```

#### Delete User (Admin)
```http
DELETE /webresources/admin/users/{id}
Authorization: Bearer {admin_token}
```

#### Update User Status (Admin)
```http
PUT /webresources/admin/users/{id}/status
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "isActive": true
}
```

#### Get All Bands (Admin)
```http
GET /webresources/admin/bands
Authorization: Bearer {admin_token}
```

#### Delete Band (Admin)
```http
DELETE /webresources/admin/bands/{id}
Authorization: Bearer {admin_token}
```

#### Get All Posts (Admin)
```http
GET /webresources/admin/posts
Authorization: Bearer {admin_token}
```

#### Delete Post (Admin)
```http
DELETE /webresources/admin/posts/{id}
Authorization: Bearer {admin_token}
```

#### Get System Statistics (Admin)
```http
GET /webresources/admin/stats
Authorization: Bearer {admin_token}
```

**Response:**
```json
{
  "users": 150,
  "bands": 45,
  "posts": 320
}
```

## JWT Token Configuration

### Environment Variables
Set the JWT secret key (recommended for production):
```bash
export JWT_SECRET="your-super-secret-key-change-in-production"
```

If not set, the default secret will be used (change this in production!).

### Token Expiration
- Default: 24 hours
- Can be modified in `JwtUtil.java`

## User Types
- **fan**: Regular users who can view and interact with content
- **artist**: Users who can create bands and posts
- **admin**: Full administrative access

## CORS Configuration
The backend is configured to allow all origins for development. For production, modify `CorsFilter.java` to restrict origins:

```java
response.setHeader("Access-Control-Allow-Origin", "https://your-frontend-domain.com");
```

## Common Issues & Solutions

### Issue: Database Connection Failed
**Solution**: 
1. Verify MySQL is running
2. Check JDBC connection pool configuration
3. Ensure database name is correct
4. Verify username/password

### Issue: Token Invalid/Expired
**Solution**:
1. Use the `/auth/refresh` endpoint to get a new token
2. Check token expiration time in `JwtUtil.java`

### Issue: CORS Errors
**Solution**:
1. Verify `CorsFilter.java` is properly configured
2. Check `web.xml` has the filter mapping
3. Restart the server

### Issue: 404 Not Found on API calls
**Solution**:
1. Verify context path is `/bandr`
2. Ensure server is running
3. Check that all REST services are registered in `ApplicationConfig.java`

## Testing the API

### Using curl
```bash
# Register
curl -X POST http://localhost:8080/bandr/webresources/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@test.com","password":"test123"}'

# Login
curl -X POST http://localhost:8080/bandr/webresources/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123"}'

# Get current user (replace TOKEN with actual token)
curl -X GET http://localhost:8080/bandr/webresources/auth/me \
  -H "Authorization: Bearer TOKEN"
```

### Using Postman
1. Import the API endpoints
2. Set base URL: `http://localhost:8080/bandr/webresources`
3. For protected endpoints, add header: `Authorization: Bearer {your_token}`

## Project Structure
```
bandr-backend-complete/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── iakk/
│       │           └── bandr/
│       │               ├── admin/          # Admin controllers
│       │               ├── auth/           # Authentication & JWT
│       │               ├── dto/            # Data Transfer Objects
│       │               ├── filter/         # CORS filter
│       │               ├── model/          # JPA Entities
│       │               └── service/        # REST Services
│       ├── resources/
│       │   └── META-INF/
│       │       └── persistence.xml
│       └── webapp/
│           └── WEB-INF/
│               └── web.xml
└── pom.xml
```

## Frontend Integration
The frontend expects the API at: `http://localhost:8080/bandr/webresources`

Make sure to:
1. Store JWT token in localStorage as `token`
2. Include token in Authorization header: `Bearer {token}`
3. Handle token expiration and refresh

## Security Considerations
- Change JWT secret in production
- Use HTTPS in production
- Implement rate limiting
- Add input validation
- Use prepared statements (already implemented via JPA)
- Restrict CORS origins in production

## Development Tips
1. Use NetBeans debugger to step through code
2. Check GlassFish server logs for errors
3. Test API endpoints with Postman before frontend integration
4. Use MySQL Workbench to verify database changes

## Support
For issues or questions:
1. Check the server logs
2. Verify database connection
3. Ensure all dependencies are installed
4. Review this README carefully

## License
[Your License Here]

## Authors
Band&R Development Team
