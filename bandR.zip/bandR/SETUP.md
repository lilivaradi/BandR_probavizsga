# Band&R Backend - Setup Guide

## Quick Setup (5 Minutes)

### Prerequisites Check
Before starting, ensure you have:
- ✅ Java JDK 8 or higher installed
- ✅ Apache NetBeans IDE (any version 8.2+)
- ✅ MySQL Server running
- ✅ GlassFish Server 4.1+ or Payara Server

### Step 1: Database Setup (2 minutes)

1. **Create the database:**
   ```sql
   CREATE DATABASE bandr_uj CHARACTER SET utf8 COLLATE utf8_general_ci;
   ```

2. **Import the schema:**
   ```bash
   mysql -u root -p bandr_uj < bandr_uj.sql
   ```
   
   Or in MySQL Workbench:
   - Open the `bandr_uj.sql` file
   - Execute the script

### Step 2: Configure GlassFish/Payara (2 minutes)

1. **Start your application server**

2. **Open Admin Console:**
   - URL: http://localhost:4848 (or your server's admin port)

3. **Create JDBC Connection Pool:**
   - Navigate to: Resources → JDBC → JDBC Connection Pools
   - Click "New"
   - Settings:
     * **Pool Name**: `bandr_pool`
     * **Resource Type**: `javax.sql.DataSource`
     * **Database Driver Vendor**: `MySQL`
   - Click "Next"
   - Additional Properties:
     * **serverName**: `localhost`
     * **portNumber**: `3306`
     * **databaseName**: `bandr_uj`
     * **user**: `root` (your MySQL username)
     * **password**: (your MySQL password)
     * **useSSL**: `false`
     * **allowPublicKeyRetrieval**: `true` (for MySQL 8+)
   - Click "Finish"
   - **Test the connection** (Ping button) - should say "Ping Succeeded"

4. **Create JDBC Resource:**
   - Navigate to: Resources → JDBC → JDBC Resources
   - Click "New"
   - Settings:
     * **JNDI Name**: `java:/bandr_uj`
     * **Pool Name**: `bandr_pool`
   - Click "OK"

### Step 3: Import & Deploy Project (1 minute)

1. **Open NetBeans**

2. **Import Project:**
   - File → Open Project
   - Navigate to `bandr-backend-complete` folder
   - Click "Open Project"

3. **Wait for Maven:**
   - Let Maven download all dependencies (this may take a minute)
   - Watch the bottom-right corner for progress

4. **Configure Server (if needed):**
   - Right-click project → Properties
   - Category "Run" → Select your GlassFish/Payara server
   - Set Context Path to `/bandr`
   - Click OK

5. **Deploy:**
   - Right-click project → "Clean and Build"
   - Right-click project → "Run"
   - Server will start and deploy the application

### Step 4: Verify Installation

1. **Check server is running:**
   Open browser to: http://localhost:8080

2. **Test the API:**
   ```bash
   curl http://localhost:8080/bandr/webresources/users
   ```
   
   Should return an empty array `[]` or existing users

3. **Test Registration:**
   ```bash
   curl -X POST http://localhost:8080/bandr/webresources/auth/register \
     -H "Content-Type: application/json" \
     -d '{
       "username": "testuser",
       "email": "test@example.com",
       "password": "test123",
       "userType": "fan"
     }'
   ```
   
   Should return a JWT token and user info

## API Endpoints Quick Reference

### Base URL
```
http://localhost:8080/bandr/webresources
```

### Authentication
- `POST /auth/register` - Register new user
- `POST /auth/login` - Login
- `GET /auth/me` - Get current user (requires token)
- `POST /auth/refresh` - Refresh token
- `POST /auth/logout` - Logout

### Core Resources
- `/users` - User management
- `/profiles` - User profiles
- `/bands` - Band management
- `/posts` - Post management
- `/postlikes` - Like management
- `/savedposts` - Saved posts
- `/messages` - Messaging
- `/samples` - Music samples

### Admin (requires admin token)
- `/admin/users` - User administration
- `/admin/bands` - Band administration
- `/admin/posts` - Post administration
- `/admin/stats` - System statistics

## Frontend Integration

### Configuration
Update your frontend's API base URL to:
```javascript
const BASE_URL = "http://localhost:8080/bandr/webresources";
```

### Authentication Flow
```javascript
// 1. Login
const response = await fetch(`${BASE_URL}/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, password })
});
const data = await response.json();

// 2. Store token
localStorage.setItem("token", data.token);
localStorage.setItem("user", JSON.stringify(data));

// 3. Use token in requests
fetch(`${BASE_URL}/protected-endpoint`, {
  headers: {
    "Authorization": `Bearer ${localStorage.getItem("token")}`
  }
});
```

## Common Issues & Solutions

### Issue: Connection pool ping fails
**Solution:**
1. Verify MySQL is running: `mysql -u root -p`
2. Check username/password in connection pool
3. For MySQL 8+, add: `allowPublicKeyRetrieval=true`
4. Try: `useSSL=false`

### Issue: "Table 'bandr_uj.users' doesn't exist"
**Solution:**
- Re-import the SQL file
- Verify database name is `bandr_uj`
- Check MySQL user has permissions

### Issue: "Deployment failed"
**Solution:**
1. Clean the project: Right-click → Clean
2. Stop the server
3. Clean and Build the project
4. Start server and Run

### Issue: "Port 8080 already in use"
**Solution:**
- Another application is using port 8080
- Change GlassFish HTTP port in: domain.xml
- Or stop the other application

### Issue: "CORS errors in browser"
**Solution:**
- Verify `CorsFilter.java` is present
- Check `web.xml` has the filter configuration
- Restart the server

## Testing with Postman

1. **Import Collection:**
   - Base URL: `http://localhost:8080/bandr/webresources`
   
2. **Register a User:**
   - Method: POST
   - URL: `/auth/register`
   - Body (JSON):
     ```json
     {
       "username": "john",
       "email": "john@test.com",
       "password": "password123"
     }
     ```
   
3. **Login:**
   - Method: POST
   - URL: `/auth/login`
   - Body (JSON):
     ```json
     {
       "email": "john@test.com",
       "password": "password123"
     }
     ```
   - Save the token from response

4. **Access Protected Resource:**
   - Method: GET
   - URL: `/auth/me`
   - Headers:
     - Key: `Authorization`
     - Value: `Bearer YOUR_TOKEN_HERE`

## Creating an Admin User

### Option 1: Direct Database
```sql
UPDATE users 
SET user_type = 'admin' 
WHERE email = 'your@email.com';
```

### Option 2: Via API
1. Register normally
2. Update database as above
3. Login again to get admin token

## Environment Variables

### JWT Secret (Production)
```bash
# Linux/Mac
export JWT_SECRET="your-super-secret-production-key-here"

# Windows
set JWT_SECRET=your-super-secret-production-key-here
```

### Database Connection
Alternatively, you can use environment variables for database:
```bash
export DB_HOST=localhost
export DB_PORT=3306
export DB_NAME=bandr_uj
export DB_USER=root
export DB_PASSWORD=your_password
```

## Next Steps

1. ✅ Backend is running
2. ✅ Test API endpoints with Postman
3. ✅ Connect your frontend
4. ✅ Create test users and data
5. ✅ Test all features end-to-end

## Support

If you encounter issues:
1. Check GlassFish/Payara server logs
2. Verify database connection
3. Test individual endpoints with curl/Postman
4. Check browser console for frontend errors

## Project Structure
```
bandr-backend-complete/
├── src/main/java/com/iakk/bandr/
│   ├── admin/              # Admin controllers
│   ├── auth/               # Authentication & JWT
│   ├── dto/                # Data Transfer Objects
│   ├── filter/             # CORS filter
│   ├── model/              # JPA Entities (Database models)
│   └── service/            # REST API Services
├── src/main/resources/
│   └── META-INF/
│       └── persistence.xml # JPA configuration
├── src/main/webapp/
│   └── WEB-INF/
│       └── web.xml         # Web app configuration
├── pom.xml                 # Maven dependencies
└── README.md               # Full documentation
```

## Development Tips

1. **Enable Hot Reload:**
   - NetBeans: Tools → Options → Java → Maven → "Skip Tests" checkbox
   
2. **View Logs:**
   - NetBeans: Output window (bottom)
   - Or: GlassFish/domains/domain1/logs/server.log

3. **Database Changes:**
   - After schema changes, restart the server
   - Or update persistence.xml schema generation

4. **API Testing:**
   - Use Postman for organized testing
   - Save requests in collections
   - Use environment variables for tokens

Happy coding! 🎸🎵
