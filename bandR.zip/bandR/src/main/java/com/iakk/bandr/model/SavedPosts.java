/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "saved_posts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SavedPosts.findAll", query = "SELECT s FROM SavedPosts s"),
    @NamedQuery(name = "SavedPosts.findBySaveId", query = "SELECT s FROM SavedPosts s WHERE s.saveId = :saveId"),
    @NamedQuery(name = "SavedPosts.findBySavedAt", query = "SELECT s FROM SavedPosts s WHERE s.savedAt = :savedAt"),
    @NamedQuery(name = "SavedPosts.findByIsDeleted", query = "SELECT s FROM SavedPosts s WHERE s.isDeleted = :isDeleted"),
    @NamedQuery(name = "SavedPosts.findByDeletedAt", query = "SELECT s FROM SavedPosts s WHERE s.deletedAt = :deletedAt")})
public class SavedPosts implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "save_id")
    private Integer saveId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "saved_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date savedAt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    @OneToOne(optional = false)
    private Users userId;
    @JoinColumn(name = "post_id", referencedColumnName = "post_id")
    @ManyToOne(optional = false)
    private Posts postId;

    public SavedPosts() {
    }

    public SavedPosts(Integer saveId) {
        this.saveId = saveId;
    }

    public SavedPosts(Integer saveId, Date savedAt, boolean isDeleted) {
        this.saveId = saveId;
        this.savedAt = savedAt;
        this.isDeleted = isDeleted;
    }

    public Integer getSaveId() {
        return saveId;
    }

    public void setSaveId(Integer saveId) {
        this.saveId = saveId;
    }

    public Date getSavedAt() {
        return savedAt;
    }

    public void setSavedAt(Date savedAt) {
        this.savedAt = savedAt;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Users getUserId() {
        return userId;
    }

    public void setUserId(Users userId) {
        this.userId = userId;
    }

    public Posts getPostId() {
        return postId;
    }

    public void setPostId(Posts postId) {
        this.postId = postId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (saveId != null ? saveId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SavedPosts)) {
            return false;
        }
        SavedPosts other = (SavedPosts) object;
        if ((this.saveId == null && other.saveId != null) || (this.saveId != null && !this.saveId.equals(other.saveId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.SavedPosts[ saveId=" + saveId + " ]";
    }
    
}
