package com.iakk.bandr.model;

public enum ModerationStatus {
    approved,
    rejected,
    flagged
}