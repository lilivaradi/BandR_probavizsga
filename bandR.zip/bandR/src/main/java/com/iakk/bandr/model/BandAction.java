package com.iakk.bandr.model;

public enum BandAction {
    suspend,
    delete
}