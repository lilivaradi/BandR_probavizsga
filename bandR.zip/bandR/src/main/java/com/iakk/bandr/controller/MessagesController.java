package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.MessagesService;
import com.iakk.bandr.service.UsersService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("messages")
public class MessagesController {

    @EJB private MessagesService messagesService;
    @EJB private UsersService    usersService;

    @GET
    @Path("inbox")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInbox(@HeaderParam("Authorization") String authHeader) {
        Integer userId = resolveUserId(authHeader);
        if (userId == null) return unauthorized();
        try { return Response.ok(messagesService.getInbox(userId)).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("conversation/{otherUserId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getConversation(@PathParam("otherUserId") Integer otherUserId,
                                    @HeaderParam("Authorization") String authHeader) {
        Integer userId = resolveUserId(authHeader);
        if (userId == null) return unauthorized();
        try { return Response.ok(messagesService.getConversation(userId, otherUserId)).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Integer id,
                            @HeaderParam("Authorization") String authHeader) {
        if (resolveUserId(authHeader) == null) return unauthorized();
        try {
            Map<String, Object> msg = messagesService.findById(id);
            return msg != null ? Response.ok(msg).build() : notFound("Üzenet nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response send(Map<String, Object> body,
                         @HeaderParam("Authorization") String authHeader) {
        Integer senderId = resolveUserId(authHeader);
        if (senderId == null) return unauthorized();

        Integer receiverId = toInt(body.get("receiverId"));
        String content     = s(body, "content");

        if (receiverId == null)             return bad("A receiverId megadása kötelező");
        if (content == null || content.isEmpty()) return bad("Az üzenet tartalma kötelező");

        try {
            messagesService.send(senderId, receiverId, content);
            return Response.status(201).entity("{\"message\": \"Üzenet sikeresen elküldve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Integer id,
                           @HeaderParam("Authorization") String authHeader) {
        if (resolveUserId(authHeader) == null) return unauthorized();
        try {
            messagesService.delete(id);
            return Response.ok("{\"message\": \"Üzenet törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private Integer resolveUserId(String authHeader) {
        String email = JwtUtil.getEmail(JwtUtil.extractToken(authHeader));
        if (email == null) return null;
        try { return usersService.findUserIdByEmail(email); }
        catch (Exception e) { return null; }
    }

    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Integer toInt(Object v) {
        if (v == null) return null;
        if (v instanceof Integer) return (Integer) v;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return null; }
    }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response bad(String m) { return Response.status(400).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
