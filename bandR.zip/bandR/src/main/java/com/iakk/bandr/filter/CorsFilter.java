package com.iakk.bandr.filter;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CorsFilter implements Filter {

    @Override
    public void init(FilterConfig fc) throws ServletException {}

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        // 1. Dinamikus origin ellenorzas
        // - http://127.0.0.1:5500 es http://localhost:5500 : Live Server
        // - null / "null" : fajlbol megnyitott frontend (file://)
        String origin = request.getHeader("Origin");
        if ("http://127.0.0.1:5500".equals(origin) || "http://localhost:5500".equals(origin)) {
            response.setHeader("Access-Control-Allow-Origin", origin);
            response.setHeader("Access-Control-Allow-Credentials", "true");
        } else if (origin == null || "null".equals(origin)) {
            response.setHeader("Access-Control-Allow-Origin", "*");
        }

        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept");

        // 2. OPTIONS preflight keres kezelese
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            response.setContentLength(0);
            response.flushBuffer();
            return;
        }

        // 3. Minden mas keres megy tovabb
        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {}
}