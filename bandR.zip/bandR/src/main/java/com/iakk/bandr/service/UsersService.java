package com.iakk.bandr.service;

import org.mindrot.jbcrypt.BCrypt;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetAllUsers, GetUserById, UpdateUser, SoftDeleteUser
 * A password_hash soha nem kerül bele a visszaadott Map-be.
 */
@Stateless
public class UsersService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    public List<Map<String, Object>> findAll() throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetAllUsers()}");
             ResultSet rs = cs.executeQuery()) {
            List<Map<String, Object>> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        }
    }

    public Map<String, Object> findById(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetUserById(?)}")) {
            cs.setInt(1, userId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /**
     * UpdateUser(user_id, username, email, password_hash, user_type)
     * Ha a password null vagy üres, a régi hash marad.
     */
    public void update(int userId, String username, String email, String newPassword)
            throws SQLException {
        try (Connection con = ds.getConnection()) {
            String hash;
            if (newPassword != null && !newPassword.isEmpty()) {
                hash = BCrypt.hashpw(newPassword, BCrypt.gensalt(12));
            } else {
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT password_hash FROM users WHERE user_id = ?")) {
                    ps.setInt(1, userId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Felhasználó nem található");
                        hash = rs.getString("password_hash");
                    }
                }
            }
            try (CallableStatement cs = con.prepareCall("{CALL UpdateUser(?, ?, ?, ?, ?)}")) {
                cs.setInt(1, userId);
                cs.setString(2, username);
                cs.setString(3, email);
                cs.setString(4, hash);
                cs.setString(5, "user");
                cs.executeUpdate();
            }
        }
    }

    /** SoftDeleteUser(user_id) */
    public void delete(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SoftDeleteUser(?)}")) {
            cs.setInt(1, userId);
            cs.executeUpdate();
        }
    }

    /** Email alapján lekéri a user_id-t (pl. token → userId konverzióhoz) */
    public Integer findUserIdByEmail(String email) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT user_id FROM users WHERE email = ? AND is_deleted = 0")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("user_id") : null;
            }
        }
    }

    private Map<String, Object> map(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("userId",   rs.getInt("user_id"));
        row.put("username", rs.getString("username"));
        row.put("email",    rs.getString("email"));
        row.put("isActive", rs.getBoolean("is_active"));
        row.put("created",  rs.getTimestamp("created"));
        // password_hash szándékosan kihagyva
        return row;
    }
}
