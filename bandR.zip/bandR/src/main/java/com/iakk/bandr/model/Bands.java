/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "bands")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bands.findAll", query = "SELECT b FROM Bands b"),
    @NamedQuery(name = "Bands.findByBandId", query = "SELECT b FROM Bands b WHERE b.bandId = :bandId"),
    @NamedQuery(name = "Bands.findByName", query = "SELECT b FROM Bands b WHERE b.name = :name"),
    @NamedQuery(name = "Bands.findByCreated", query = "SELECT b FROM Bands b WHERE b.created = :created"),
    @NamedQuery(name = "Bands.findByIsDeleted", query = "SELECT b FROM Bands b WHERE b.isDeleted = :isDeleted"),
    @NamedQuery(name = "Bands.findByDeletedAt", query = "SELECT b FROM Bands b WHERE b.deletedAt = :deletedAt")})
public class Bands implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "band_id")
    private Integer bandId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "name")
    private String name;
    @Lob
    @Size(max = 65535)
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bandId")
    private Collection<AdminBandActions> adminBandActionsCollection;
    @JoinColumn(name = "created_by", referencedColumnName = "user_id")
    @ManyToOne
    private Users createdBy;
    @OneToMany(mappedBy = "bandId")
    private Collection<Posts> postsCollection;
    @OneToMany(mappedBy = "bandId")
    private Collection<Samples> samplesCollection;

    public Bands() {
    }

    public Bands(Integer bandId) {
        this.bandId = bandId;
    }

    public Bands(Integer bandId, String name, Date created, boolean isDeleted) {
        this.bandId = bandId;
        this.name = name;
        this.created = created;
        this.isDeleted = isDeleted;
    }

    public Integer getBandId() {
        return bandId;
    }

    public void setBandId(Integer bandId) {
        this.bandId = bandId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    @XmlTransient
    public Collection<AdminBandActions> getAdminBandActionsCollection() {
        return adminBandActionsCollection;
    }

    public void setAdminBandActionsCollection(Collection<AdminBandActions> adminBandActionsCollection) {
        this.adminBandActionsCollection = adminBandActionsCollection;
    }

    public Users getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Users createdBy) {
        this.createdBy = createdBy;
    }

    @XmlTransient
    public Collection<Posts> getPostsCollection() {
        return postsCollection;
    }

    public void setPostsCollection(Collection<Posts> postsCollection) {
        this.postsCollection = postsCollection;
    }

    @XmlTransient
    public Collection<Samples> getSamplesCollection() {
        return samplesCollection;
    }

    public void setSamplesCollection(Collection<Samples> samplesCollection) {
        this.samplesCollection = samplesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bandId != null ? bandId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bands)) {
            return false;
        }
        Bands other = (Bands) object;
        if ((this.bandId == null && other.bandId != null) || (this.bandId != null && !this.bandId.equals(other.bandId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.Bands[ bandId=" + bandId + " ]";
    }
    
}
