/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Enumerated;
import javax.persistence.EnumType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "post_moderation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PostModeration.findAll", query = "SELECT p FROM PostModeration p"),
    @NamedQuery(name = "PostModeration.findById", query = "SELECT p FROM PostModeration p WHERE p.id = :id"),
    @NamedQuery(name = "PostModeration.findByStatus", query = "SELECT p FROM PostModeration p WHERE p.status = :status"),
    @NamedQuery(name = "PostModeration.findByModeratedAt", query = "SELECT p FROM PostModeration p WHERE p.moderatedAt = :moderatedAt"),
    @NamedQuery(name = "PostModeration.findByIsDeleted", query = "SELECT p FROM PostModeration p WHERE p.isDeleted = :isDeleted"),
    @NamedQuery(name = "PostModeration.findByDeletedAt", query = "SELECT p FROM PostModeration p WHERE p.deletedAt = :deletedAt")})
public class PostModeration implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 8)
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ModerationStatus status;
    @Lob
    @Size(max = 65535)
    @Column(name = "reason")
    private String reason;
    @Basic(optional = false)
    @NotNull
    @Column(name = "moderated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date moderatedAt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @JoinColumn(name = "admin_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Admins adminId;
    @JoinColumn(name = "post_id", referencedColumnName = "post_id")
    @ManyToOne(optional = false)
    private Posts postId;

    public PostModeration() {
    }

    public PostModeration(Integer id) {
        this.id = id;
    }

    public PostModeration(Integer id, Date moderatedAt, boolean isDeleted) {
        this.id = id;
        this.moderatedAt = moderatedAt;
        this.isDeleted = isDeleted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ModerationStatus getStatus() {
        return status;
    }

    public void setStatus(ModerationStatus status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getModeratedAt() {
        return moderatedAt;
    }

    public void setModeratedAt(Date moderatedAt) {
        this.moderatedAt = moderatedAt;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Admins getAdminId() {
        return adminId;
    }

    public void setAdminId(Admins adminId) {
        this.adminId = adminId;
    }

    public Posts getPostId() {
        return postId;
    }

    public void setPostId(Posts postId) {
        this.postId = postId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PostModeration)) {
            return false;
        }
        PostModeration other = (PostModeration) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.PostModeration[ id=" + id + " ]";
    }
    
}