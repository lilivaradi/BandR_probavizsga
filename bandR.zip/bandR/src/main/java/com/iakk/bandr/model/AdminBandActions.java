/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Enumerated;
import javax.persistence.EnumType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "admin_band_actions")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AdminBandActions.findAll", query = "SELECT a FROM AdminBandActions a"),
    @NamedQuery(name = "AdminBandActions.findById", query = "SELECT a FROM AdminBandActions a WHERE a.id = :id"),
    @NamedQuery(name = "AdminBandActions.findByAction", query = "SELECT a FROM AdminBandActions a WHERE a.action = :action"),
    @NamedQuery(name = "AdminBandActions.findByCreatedAt", query = "SELECT a FROM AdminBandActions a WHERE a.createdAt = :createdAt"),
    @NamedQuery(name = "AdminBandActions.findByIsDeleted", query = "SELECT a FROM AdminBandActions a WHERE a.isDeleted = :isDeleted"),
    @NamedQuery(name = "AdminBandActions.findByDeletedAt", query = "SELECT a FROM AdminBandActions a WHERE a.deletedAt = :deletedAt")})
public class AdminBandActions implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private BandAction action;
    @Lob
    @Size(max = 65535)
    @Column(name = "reason")
    private String reason;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @JoinColumn(name = "admin_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Admins adminId;
    @JoinColumn(name = "band_id", referencedColumnName = "band_id")
    @ManyToOne(optional = false)
    private Bands bandId;

    public AdminBandActions() {
    }

    public AdminBandActions(Integer id) {
        this.id = id;
    }

    public AdminBandActions(Integer id, BandAction action, Date createdAt, boolean isDeleted) {
        this.id = id;
        this.action = action;
        this.createdAt = createdAt;
        this.isDeleted = isDeleted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BandAction getAction() {
        return action;
    }

    public void setAction(BandAction action) {
        this.action = action;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Admins getAdminId() {
        return adminId;
    }

    public void setAdminId(Admins adminId) {
        this.adminId = adminId;
    }

    public Bands getBandId() {
        return bandId;
    }

    public void setBandId(Bands bandId) {
        this.bandId = bandId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AdminBandActions)) {
            return false;
        }
        AdminBandActions other = (AdminBandActions) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.AdminBandActions[ id=" + id + " ]";
    }
    
}