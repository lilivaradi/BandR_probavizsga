package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetInbox, GetMessagesBetweenUsers, GetMessageById, SendMessage, SoftDeleteMessages
 */
@Stateless
public class MessagesService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    /** GetInbox(user_id) — beérkező üzenetek */
    public List<Map<String, Object>> getInbox(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetInbox(?)}")) {
            cs.setInt(1, userId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("messageId", rs.getInt("message_id"));
                    row.put("senderId",  rs.getInt("sender_id"));
                    row.put("content",   rs.getString("content"));
                    row.put("sent",      rs.getTimestamp("sent"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** GetMessagesBetweenUsers(user1_id, user2_id) — két user közötti üzenetek */
    public List<Map<String, Object>> getConversation(int userId, int otherUserId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetMessagesBetweenUsers(?, ?)}")) {
            cs.setInt(1, userId);
            cs.setInt(2, otherUserId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("messageId",  rs.getInt("message_id"));
                    row.put("senderId",   rs.getInt("sender_id"));
                    row.put("receiverId", rs.getInt("receiver_id"));
                    row.put("content",    rs.getString("content"));
                    row.put("sent",       rs.getTimestamp("sent"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** GetMessageById(message_id) */
    public Map<String, Object> findById(int messageId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetMessageById(?)}")) {
            cs.setInt(1, messageId);
            try (ResultSet rs = cs.executeQuery()) {
                if (!rs.next()) return null;
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("messageId",  rs.getInt("message_id"));
                row.put("senderId",   rs.getInt("sender_id"));
                row.put("receiverId", rs.getInt("receiver_id"));
                row.put("content",    rs.getString("content"));
                row.put("sent",       rs.getTimestamp("sent"));
                return row;
            }
        }
    }

    /** SendMessage(sender_id, receiver_id, content) */
    public void send(int senderId, int receiverId, String content) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SendMessage(?, ?, ?)}")) {
            cs.setInt(1, senderId);
            cs.setInt(2, receiverId);
            cs.setString(3, content);
            cs.executeUpdate();
        }
    }

    /** SoftDeleteMessages(message_id) */
    public void delete(int messageId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SoftDeleteMessages(?)}")) {
            cs.setInt(1, messageId);
            cs.executeUpdate();
        }
    }
}
