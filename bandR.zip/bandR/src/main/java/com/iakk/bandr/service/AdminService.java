package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: sp_dashboard_summary, sp_activate_user, sp_suspend_user
 */
@Stateless
public class AdminService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    /** sp_dashboard_summary() — statisztika */
    public Map<String, Object> getDashboard() throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL sp_dashboard_summary()}");
             ResultSet rs = cs.executeQuery()) {
            if (!rs.next()) return Collections.emptyMap();
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("totalUsers",    rs.getInt("total_users"));
            row.put("totalBands",    rs.getInt("total_bands"));
            row.put("totalPosts",    rs.getInt("total_posts"));
            row.put("totalMessages", rs.getInt("total_messages"));
            row.put("totalLikes",    rs.getInt("total_likes"));
            row.put("totalSamples",  rs.getInt("total_samples"));
            return row;
        }
    }

    /** sp_activate_user(admin_id, user_id) */
    public void activateUser(int adminId, int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL sp_activate_user(?, ?)}")) {
            cs.setInt(1, adminId);
            cs.setInt(2, userId);
            cs.executeUpdate();
        }
    }

    /** sp_suspend_user(admin_id, user_id, reason) */
    public void suspendUser(int adminId, int userId, String reason) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL sp_suspend_user(?, ?, ?)}")) {
            cs.setInt(1, adminId);
            cs.setInt(2, userId);
            cs.setString(3, reason != null ? reason : "Admin által felfüggesztve");
            cs.executeUpdate();
        }
    }

    /** Email alapján lekéri az admin id-t */
    public Integer findAdminIdByEmail(String email) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT id FROM admins WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("id") : null;
            }
        }
    }
}
