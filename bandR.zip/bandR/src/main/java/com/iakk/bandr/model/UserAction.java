package com.iakk.bandr.model;

public enum UserAction {
    suspend,
    activate,
    delete
}