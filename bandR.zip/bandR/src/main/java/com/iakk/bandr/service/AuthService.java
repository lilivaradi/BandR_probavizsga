package com.iakk.bandr.service;

import org.mindrot.jbcrypt.BCrypt;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: CreateUser, CreateProfile
 */
@Stateless
public class AuthService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    /**
     * Új felhasználó regisztrálása.
     * Elmenti a users táblába, majd létrehozza az üres profilt is.
     * @return a létrejött user_id
     * @throws IllegalArgumentException ha az email/username már foglalt
     */
    public int registerUser(String username, String email, String password,
                            String bio, String instruments, String favGenres, String location)
            throws SQLException {

        try (Connection con = ds.getConnection()) {

            // Egyediség ellenőrzés
            if (exists(con, "SELECT 1 FROM users WHERE email = ?", email))
                throw new IllegalArgumentException("Ez az email cím már foglalt");
            if (exists(con, "SELECT 1 FROM users WHERE username = ?", username))
                throw new IllegalArgumentException("Ez a felhasználónév már foglalt");

            // Jelszó hash
            String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));

            // CreateUser(username, email, password_hash)
            try (CallableStatement cs = con.prepareCall("{CALL CreateUser(?, ?, ?)}")) {
                cs.setString(1, username);
                cs.setString(2, email);
                cs.setString(3, hash);
                cs.executeUpdate();
            }

            // Frissen létrehozott user_id lekérése
            int userId;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT user_id FROM users WHERE email = ?")) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Felhasználó mentése sikertelen");
                    userId = rs.getInt("user_id");
                }
            }

            // CreateProfile(user_id, bio, instruments, fav_genres, location)
            try (CallableStatement cs = con.prepareCall("{CALL CreateProfile(?, ?, ?, ?, ?)}")) {
                cs.setInt(1, userId);
                cs.setString(2, bio != null ? bio : "");
                cs.setString(3, instruments != null ? instruments : "");
                cs.setString(4, favGenres != null ? favGenres : "");
                cs.setString(5, location != null ? location : "");
                cs.executeUpdate();
            }

            return userId;
        }
    }

    /**
     * Felhasználó bejelentkezés. Visszaadja a user adatait, vagy null-t ha hibás.
     */
    public Map<String, Object> loginUser(String email, String password) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT user_id, username, email, password_hash, is_active " +
                "FROM users WHERE email = ? AND is_deleted = 0")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                if (!rs.getBoolean("is_active"))
                    throw new IllegalStateException("Ez a fiók le van tiltva");
                if (!BCrypt.checkpw(password, rs.getString("password_hash")))
                    return null;

                Map<String, Object> user = new LinkedHashMap<>();
                user.put("userId",   rs.getInt("user_id"));
                user.put("username", rs.getString("username"));
                user.put("email",    rs.getString("email"));
                return user;
            }
        }
    }

    /**
     * Admin bejelentkezés az admins táblából.
     */
    public Map<String, Object> loginAdmin(String email, String password) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT id, username, email, password_hash, is_active " +
                "FROM admins WHERE email = ? AND is_deleted = 0")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                if (!rs.getBoolean("is_active"))
                    throw new IllegalStateException("Ez az admin fiók le van tiltva");
                if (!BCrypt.checkpw(password, rs.getString("password_hash")))
                    return null;

                Map<String, Object> admin = new LinkedHashMap<>();
                admin.put("adminId",  rs.getInt("id"));
                admin.put("username", rs.getString("username"));
                admin.put("email",    rs.getString("email"));
                return admin;
            }
        }
    }

    /**
     * Bejelentkezett user adatai email alapján (GET /auth/me).
     */
    public Map<String, Object> getUserByEmail(String email) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT user_id, username, email, is_active, created FROM users WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Map<String, Object> user = new LinkedHashMap<>();
                user.put("userId",   rs.getInt("user_id"));
                user.put("username", rs.getString("username"));
                user.put("email",    rs.getString("email"));
                user.put("isActive", rs.getBoolean("is_active"));
                user.put("role",     "user");
                return user;
            }
        }
    }

    /**
     * Admin adatai email alapján (GET /auth/me admin tokennel).
     */
    public Map<String, Object> getAdminByEmail(String email) throws SQLException {
        try (Connection con = ds.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT id, username, email, is_active FROM admins WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Map<String, Object> admin = new LinkedHashMap<>();
                admin.put("adminId",  rs.getInt("id"));
                admin.put("username", rs.getString("username"));
                admin.put("email",    rs.getString("email"));
                admin.put("isActive", rs.getBoolean("is_active"));
                admin.put("role",     "admin");
                return admin;
            }
        }
    }

    private boolean exists(Connection con, String sql, String val) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, val);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
}