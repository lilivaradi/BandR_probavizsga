package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetProfileByUser, UpdateProfile, HardDeleteProfile
 */
@Stateless
public class ProfilesService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    public Map<String, Object> findByUserId(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetProfileByUser(?)}")) {
            cs.setInt(1, userId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** UpdateProfile(user_id, bio, instruments, fav_genres, location, looking_for_band, looking_for_fans) */
    public void update(int userId, String bio, String instruments, String favGenres,
                       String location, boolean lookingForBand, boolean lookingForFans)
            throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL UpdateProfile(?, ?, ?, ?, ?, ?, ?)}")) {
            cs.setInt(1, userId);
            cs.setString(2, bio != null ? bio : "");
            cs.setString(3, instruments != null ? instruments : "");
            cs.setString(4, favGenres != null ? favGenres : "");
            cs.setString(5, location != null ? location : "");
            cs.setBoolean(6, lookingForBand);
            cs.setBoolean(7, lookingForFans);
            cs.executeUpdate();
        }
    }

    /** HardDeleteProfile(user_id) */
    public void delete(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL HardDeleteProfile(?)}")) {
            cs.setInt(1, userId);
            cs.executeUpdate();
        }
    }

    private Map<String, Object> map(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("userId",          rs.getInt("user_id"));
        row.put("bio",             rs.getString("bio"));
        row.put("instruments",     rs.getString("instruments"));
        row.put("favGenres",       rs.getString("fav_genres"));
        row.put("location",        rs.getString("location"));
        row.put("age",             rs.getObject("age"));
        row.put("experienceYears", rs.getObject("experience_years"));
        row.put("availability",    rs.getString("availability"));
        row.put("preferredRole",   rs.getString("preferred_role"));
        row.put("influences",      rs.getString("influences"));
        row.put("equipment",       rs.getString("equipment"));
        row.put("pfpUrl",          rs.getString("pfp_url"));
        return row;
    }
}
