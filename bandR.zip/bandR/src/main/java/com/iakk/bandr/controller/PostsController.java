package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.PostsService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("posts")
public class PostsController {

    @EJB
    private PostsService postsService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        try { return Response.ok(postsService.findAll()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Integer id) {
        try {
            Map<String, Object> post = postsService.findById(id);
            return post != null ? Response.ok(post).build() : notFound("Poszt nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("band/{bandId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getByBand(@PathParam("bandId") Integer bandId) {
        try { return Response.ok(postsService.findByBand(bandId)).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        Integer bandId = toInt(body.get("bandId"));
        String title   = s(body, "title");
        String content = s(body, "content");

        if (bandId == null)             return bad("A bandId megadása kötelező");
        if (title == null || title.isEmpty()) return bad("A cím megadása kötelező");

        try {
            postsService.create(bandId, title, content);
            return Response.status(201).entity("{\"message\": \"Poszt sikeresen létrehozva\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Integer id, Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        String title   = s(body, "title");
        String content = s(body, "content");

        if (title == null || title.isEmpty()) return bad("A cím megadása kötelező");

        try {
            postsService.update(id, title, content);
            return Response.ok("{\"message\": \"Poszt sikeresen frissítve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Integer id,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            postsService.delete(id);
            return Response.ok("{\"message\": \"Poszt sikeresen törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private boolean loggedIn(String h) { return JwtUtil.isValid(JwtUtil.extractToken(h)); }
    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Integer toInt(Object v) {
        if (v == null) return null;
        if (v instanceof Integer) return (Integer) v;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return null; }
    }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response bad(String m) { return Response.status(400).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
