package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetSavedPostsByUser, IsPostSaved, ToggleSavePost, UnsavePost
 */
@Stateless
public class SavedPostsService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    /** GetSavedPostsByUser(user_id) */
    public List<Map<String, Object>> findByUser(int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetSavedPostsByUser(?)}")) {
            cs.setInt(1, userId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("postId",  rs.getInt("post_id"));
                    row.put("title",   rs.getString("title"));
                    row.put("content", rs.getString("content"));
                    row.put("savedAt", rs.getTimestamp("saved_at"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** IsPostSaved(user_id, post_id) */
    public boolean isSaved(int userId, int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL IsPostSaved(?, ?)}")) {
            cs.setInt(1, userId);
            cs.setInt(2, postId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() && rs.getInt("is_saved") == 1;
            }
        }
    }

    /** ToggleSavePost(user_id, post_id) */
    public void toggle(int userId, int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL ToggleSavePost(?, ?)}")) {
            cs.setInt(1, userId);
            cs.setInt(2, postId);
            cs.executeUpdate();
        }
    }

    /** UnsavePost(user_id, post_id) */
    public void unsave(int userId, int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL UnsavePost(?, ?)}")) {
            cs.setInt(1, userId);
            cs.setInt(2, postId);
            cs.executeUpdate();
        }
    }
}
