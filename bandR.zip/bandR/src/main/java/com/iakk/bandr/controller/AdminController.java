package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.AdminService;
import com.iakk.bandr.service.BandsService;
import com.iakk.bandr.service.PostsService;
import com.iakk.bandr.service.UsersService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("admin")
public class AdminController {

    @EJB private AdminService  adminService;
    @EJB private UsersService  usersService;
    @EJB private BandsService  bandsService;
    @EJB private PostsService  postsService;

    @GET
    @Path("stats")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStats(@HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try { return Response.ok(adminService.getDashboard()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    // --- USERS ---

    @GET
    @Path("users")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllUsers(@HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try { return Response.ok(usersService.findAll()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("users/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserById(@PathParam("id") Integer id,
                                @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            Map<String, Object> user = usersService.findById(id);
            return user != null ? Response.ok(user).build() : notFound("Felhasználó nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("users/{id}/activate")
    @Produces(MediaType.APPLICATION_JSON)
    public Response activateUser(@PathParam("id") Integer userId,
                                 @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            Integer adminId = adminService.findAdminIdByEmail(
                    JwtUtil.getEmail(JwtUtil.extractToken(authHeader)));
            adminService.activateUser(adminId, userId);
            return Response.ok("{\"message\": \"Felhasználó aktiválva\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("users/{id}/suspend")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response suspendUser(@PathParam("id") Integer userId,
                                Map<String, Object> body,
                                @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            Integer adminId = adminService.findAdminIdByEmail(
                    JwtUtil.getEmail(JwtUtil.extractToken(authHeader)));
            String reason = (body != null && body.get("reason") != null)
                          ? body.get("reason").toString() : null;
            adminService.suspendUser(adminId, userId, reason);
            return Response.ok("{\"message\": \"Felhasználó felfüggesztve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("users/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteUser(@PathParam("id") Integer id,
                               @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            usersService.delete(id);
            return Response.ok("{\"message\": \"Felhasználó törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    // --- BANDS ---

    @GET
    @Path("bands")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBands(@HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try { return Response.ok(bandsService.findAll()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("bands/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteBand(@PathParam("id") Integer id,
                               @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            bandsService.delete(id);
            return Response.ok("{\"message\": \"Banda törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    // --- POSTS ---

    @GET
    @Path("posts")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllPosts(@HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try { return Response.ok(postsService.findAll()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("posts/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePost(@PathParam("id") Integer id,
                               @HeaderParam("Authorization") String authHeader) {
        Response check = requireAdmin(authHeader);
        if (check != null) return check;
        try {
            postsService.delete(id);
            return Response.ok("{\"message\": \"Poszt törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    // --- helpers ---
    private Response requireAdmin(String authHeader) {
        String token = JwtUtil.extractToken(authHeader);
        if (JwtUtil.getEmail(token) == null)
            return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build();
        if (!JwtUtil.isAdmin(token))
            return Response.status(403).entity("{\"error\":\"Admin jogosultság szükséges\"}").build();
        return null;
    }

    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
