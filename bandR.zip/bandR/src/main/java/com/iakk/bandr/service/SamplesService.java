package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetSampleById, GetSamplesByBand, AddSample, UpdateSample, SoftDeleteSample
 */
@Stateless
public class SamplesService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    public Map<String, Object> findById(int sampleId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetSampleById(?)}")) {
            cs.setInt(1, sampleId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapFull(rs) : null;
            }
        }
    }

    public List<Map<String, Object>> findByBand(int bandId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetSamplesByBand(?)}")) {
            cs.setInt(1, bandId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("sampleId", rs.getInt("sample_id"));
                    row.put("title",    rs.getString("title"));
                    row.put("fileUrl",  rs.getString("file_url"));
                    row.put("uploaded", rs.getTimestamp("uploaded"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** AddSample(band_id, title, file_url) */
    public void create(int bandId, String title, String fileUrl) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL AddSample(?, ?, ?)}")) {
            cs.setInt(1, bandId);
            cs.setString(2, title);
            cs.setString(3, fileUrl);
            cs.executeUpdate();
        }
    }

    /** UpdateSample(sample_id, title, file_url) */
    public void update(int sampleId, String title, String fileUrl) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL UpdateSample(?, ?, ?)}")) {
            cs.setInt(1, sampleId);
            cs.setString(2, title);
            cs.setString(3, fileUrl);
            cs.executeUpdate();
        }
    }

    /** SoftDeleteSample(sample_id) */
    public void delete(int sampleId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SoftDeleteSample(?)}")) {
            cs.setInt(1, sampleId);
            cs.executeUpdate();
        }
    }

    private Map<String, Object> mapFull(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("sampleId", rs.getInt("sample_id"));
        row.put("bandId",   rs.getInt("band_id"));
        row.put("title",    rs.getString("title"));
        row.put("fileUrl",  rs.getString("file_url"));
        row.put("uploaded", rs.getTimestamp("uploaded"));
        return row;
    }
}
