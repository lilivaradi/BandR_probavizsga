package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetAllBand, GetBandById, CreateBand, UpdateBand, SoftDeleteBands
 */
@Stateless
public class BandsService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    public List<Map<String, Object>> findAll() throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetAllBand()}");
             ResultSet rs = cs.executeQuery()) {
            List<Map<String, Object>> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        }
    }

    public Map<String, Object> findById(int bandId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetBandById(?)}")) {
            cs.setInt(1, bandId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** CreateBand(name, description, created_by) */
    public void create(String name, String description, int createdBy) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL CreateBand(?, ?, ?)}")) {
            cs.setString(1, name);
            cs.setString(2, description != null ? description : "");
            cs.setInt(3, createdBy);
            cs.executeUpdate();
        }
    }

    /** UpdateBand(band_id, name, description, created_by) */
    public void update(int bandId, String name, String description, int createdBy) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL UpdateBand(?, ?, ?, ?)}")) {
            cs.setInt(1, bandId);
            cs.setString(2, name);
            cs.setString(3, description != null ? description : "");
            cs.setInt(4, createdBy);
            cs.executeUpdate();
        }
    }

    /** SoftDeleteBands(band_id) */
    public void delete(int bandId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SoftDeleteBands(?)}")) {
            cs.setInt(1, bandId);
            cs.executeUpdate();
        }
    }

    private Map<String, Object> map(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("bandId",      rs.getInt("band_id"));
        row.put("name",        rs.getString("name"));
        row.put("description", rs.getString("description"));
        row.put("createdBy",   rs.getInt("created_by"));
        row.put("created",     rs.getTimestamp("created"));
        return row;
    }
}
