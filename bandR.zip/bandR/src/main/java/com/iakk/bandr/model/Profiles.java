/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "profiles")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Profiles.findAll", query = "SELECT p FROM Profiles p"),
    @NamedQuery(name = "Profiles.findByUserId", query = "SELECT p FROM Profiles p WHERE p.userId = :userId"),
    @NamedQuery(name = "Profiles.findByLocation", query = "SELECT p FROM Profiles p WHERE p.location = :location"),
    @NamedQuery(name = "Profiles.findByAge", query = "SELECT p FROM Profiles p WHERE p.age = :age"),
    @NamedQuery(name = "Profiles.findByExperienceYears", query = "SELECT p FROM Profiles p WHERE p.experienceYears = :experienceYears"),
    @NamedQuery(name = "Profiles.findByAvailability", query = "SELECT p FROM Profiles p WHERE p.availability = :availability"),
    @NamedQuery(name = "Profiles.findByPreferredRole", query = "SELECT p FROM Profiles p WHERE p.preferredRole = :preferredRole"),
    @NamedQuery(name = "Profiles.findByInfluences", query = "SELECT p FROM Profiles p WHERE p.influences = :influences"),
    @NamedQuery(name = "Profiles.findByEquipment", query = "SELECT p FROM Profiles p WHERE p.equipment = :equipment"),
    @NamedQuery(name = "Profiles.findByPfpUrl", query = "SELECT p FROM Profiles p WHERE p.pfpUrl = :pfpUrl"),
    @NamedQuery(name = "Profiles.findByIsDeleted", query = "SELECT p FROM Profiles p WHERE p.isDeleted = :isDeleted"),
    @NamedQuery(name = "Profiles.findByDeletedAt", query = "SELECT p FROM Profiles p WHERE p.deletedAt = :deletedAt")})
public class Profiles implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "user_id")
    private Integer userId;
    @Lob
    @Size(max = 65535)
    @Column(name = "bio")
    private String bio;
    @Lob
    @Size(max = 65535)
    @Column(name = "instruments")
    private String instruments;
    @Lob
    @Size(max = 65535)
    @Column(name = "fav_genres")
    private String favGenres;
    @Size(max = 100)
    @Column(name = "location")
    private String location;
    @Column(name = "age")
    private Integer age;
    @Column(name = "experience_years")
    private Integer experienceYears;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "availability")
    private String availability;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "preferred_role")
    private String preferredRole;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "influences")
    private String influences;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "equipment")
    private String equipment;
    @Size(max = 200)
    @Column(name = "pfp_url")
    private String pfpUrl;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @JoinColumn(name = "user_id", referencedColumnName = "user_id", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Users users;

    public Profiles() {
    }

    public Profiles(Integer userId) {
        this.userId = userId;
    }

    public Profiles(Integer userId, String availability, String preferredRole, String influences, String equipment, boolean isDeleted) {
        this.userId = userId;
        this.availability = availability;
        this.preferredRole = preferredRole;
        this.influences = influences;
        this.equipment = equipment;
        this.isDeleted = isDeleted;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getInstruments() {
        return instruments;
    }

    public void setInstruments(String instruments) {
        this.instruments = instruments;
    }

    public String getFavGenres() {
        return favGenres;
    }

    public void setFavGenres(String favGenres) {
        this.favGenres = favGenres;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public String getPreferredRole() {
        return preferredRole;
    }

    public void setPreferredRole(String preferredRole) {
        this.preferredRole = preferredRole;
    }

    public String getInfluences() {
        return influences;
    }

    public void setInfluences(String influences) {
        this.influences = influences;
    }

    public String getEquipment() {
        return equipment;
    }

    public void setEquipment(String equipment) {
        this.equipment = equipment;
    }

    public String getPfpUrl() {
        return pfpUrl;
    }

    public void setPfpUrl(String pfpUrl) {
        this.pfpUrl = pfpUrl;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userId != null ? userId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Profiles)) {
            return false;
        }
        Profiles other = (Profiles) object;
        if ((this.userId == null && other.userId != null) || (this.userId != null && !this.userId.equals(other.userId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.Profiles[ userId=" + userId + " ]";
    }
    
}
