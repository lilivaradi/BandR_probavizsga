package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.SamplesService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("samples")
public class SamplesController {

    @EJB
    private SamplesService samplesService;

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Integer id) {
        try {
            Map<String, Object> sample = samplesService.findById(id);
            return sample != null ? Response.ok(sample).build() : notFound("Sample nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("band/{bandId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getByBand(@PathParam("bandId") Integer bandId) {
        try { return Response.ok(samplesService.findByBand(bandId)).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        Integer bandId = toInt(body.get("bandId"));
        String title   = s(body, "title");
        String fileUrl = s(body, "fileUrl");

        if (bandId == null)               return bad("A bandId megadása kötelező");
        if (title == null || title.isEmpty())   return bad("A cím megadása kötelező");
        if (fileUrl == null || fileUrl.isEmpty()) return bad("A fileUrl megadása kötelező");

        try {
            samplesService.create(bandId, title, fileUrl);
            return Response.status(201).entity("{\"message\": \"Sample sikeresen feltöltve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Integer id, Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        String title   = s(body, "title");
        String fileUrl = s(body, "fileUrl");

        if (title == null || title.isEmpty())   return bad("A cím megadása kötelező");
        if (fileUrl == null || fileUrl.isEmpty()) return bad("A fileUrl megadása kötelező");

        try {
            samplesService.update(id, title, fileUrl);
            return Response.ok("{\"message\": \"Sample sikeresen frissítve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Integer id,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            samplesService.delete(id);
            return Response.ok("{\"message\": \"Sample törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private boolean loggedIn(String h) { return JwtUtil.isValid(JwtUtil.extractToken(h)); }
    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Integer toInt(Object v) {
        if (v == null) return null;
        if (v instanceof Integer) return (Integer) v;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return null; }
    }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response bad(String m) { return Response.status(400).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
