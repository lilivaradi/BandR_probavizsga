package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.UsersService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("users")
public class UsersController {

    @EJB
    private UsersService usersService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try { return Response.ok(usersService.findAll()).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Integer id,
                            @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            Map<String, Object> user = usersService.findById(id);
            return user != null ? Response.ok(user).build() : notFound("Felhasználó nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Integer id, Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        String username = s(body, "username");
        String email    = s(body, "email");
        String password = s(body, "password");

        if (username == null || username.isEmpty()) return bad("A felhasználónév kötelező");
        if (email == null || email.isEmpty())       return bad("Az email cím kötelező");
        if (password != null && !password.isEmpty() && password.length() < 6)
            return bad("A jelszónak legalább 6 karakter hosszúnak kell lennie");

        try {
            usersService.update(id, username, email.toLowerCase(), password);
            return Response.ok("{\"message\": \"Felhasználói adatok frissítve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Integer id,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            usersService.delete(id);
            return Response.ok("{\"message\": \"Felhasználó törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private boolean loggedIn(String h) { return JwtUtil.isValid(JwtUtil.extractToken(h)); }
    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response bad(String m) { return Response.status(400).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
