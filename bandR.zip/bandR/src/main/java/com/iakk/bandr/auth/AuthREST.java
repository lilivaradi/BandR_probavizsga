package com.iakk.bandr.auth;

import com.iakk.bandr.service.AuthService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

/**
 *
 * POST /webresources/auth/register
 * POST /webresources/auth/login
 * POST /webresources/auth/admin/login
 * GET  /webresources/auth/me
 * POST /webresources/auth/refresh
 * POST /webresources/auth/logout
 */
@Path("auth")
public class AuthREST {

    @EJB
    private AuthService authService;

    @POST
    @Path("register")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response register(Map<String, Object> body) {
        String username = s(body, "username");
        String email    = s(body, "email");
        String password = s(body, "password");

        if (username == null || username.isEmpty())
            return bad("A felhasználónév megadása kötelező");
        if (email == null || email.isEmpty())
            return bad("Az email cím megadása kötelező");
        if (password == null || password.length() < 6)
            return bad("A jelszónak legalább 6 karakter hosszúnak kell lennie");

        try {
            int userId = authService.registerUser(
                    username, email.toLowerCase(),
                    password,
                    s(body, "bio"), s(body, "instruments"),
                    s(body, "favGenres"), s(body, "location")
            );

            String token = JwtUtil.generateToken(email.toLowerCase(), "user");

            Map<String, Object> res = new LinkedHashMap<>();
            res.put("message",  "Sikeres regisztráció! Üdvözlünk a BandR közösségében, "
                                + username + "! 🎸 Jó zenélést kívánunk!");
            res.put("token",    token);
            res.put("userId",   userId);
            res.put("username", username);
            res.put("email",    email.toLowerCase());
            res.put("role",     "user");
            return Response.status(201).entity(res).build();

        } catch (IllegalArgumentException e) {
            return conflict(e.getMessage());
        } catch (Exception e) {
            return serverError("Regisztráció sikertelen: " + e.getMessage());
        }
    }

    @POST
    @Path("login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(Map<String, Object> body) {
        String email    = s(body, "email");
        String password = s(body, "password");

        if (email == null || email.isEmpty()) return bad("Az email cím megadása kötelező");
        if (password == null || password.isEmpty()) return bad("A jelszó megadása kötelező");

        try {
            Map<String, Object> user = authService.loginUser(email.toLowerCase(), password);
            if (user == null)
                return Response.status(401).entity(err("Helytelen email cím vagy jelszó")).build();

            String token = JwtUtil.generateToken(email.toLowerCase(), "user");
            user.put("token", token);
            user.put("role",  "user");
            return Response.ok(user).build();

        } catch (IllegalStateException e) {
            return Response.status(403).entity(err(e.getMessage())).build();
        } catch (Exception e) {
            return serverError("Bejelentkezés sikertelen: " + e.getMessage());
        }
    }

    @POST
    @Path("admin/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response adminLogin(Map<String, Object> body) {
        String email    = s(body, "email");
        String password = s(body, "password");

        if (email == null || email.isEmpty()) return bad("Az email cím megadása kötelező");
        if (password == null || password.isEmpty()) return bad("A jelszó megadása kötelező");

        try {
            Map<String, Object> admin = authService.loginAdmin(email.toLowerCase(), password);
            if (admin == null)
                return Response.status(401).entity(err("Helytelen email cím vagy jelszó")).build();

            String token = JwtUtil.generateToken(email.toLowerCase(), "admin");
            admin.put("token", token);
            admin.put("role",  "admin");
            return Response.ok(admin).build();

        } catch (IllegalStateException e) {
            return Response.status(403).entity(err(e.getMessage())).build();
        } catch (Exception e) {
            return serverError("Admin bejelentkezés sikertelen: " + e.getMessage());
        }
    }

    @GET
    @Path("me")
    @Produces(MediaType.APPLICATION_JSON)
    public Response me(@HeaderParam("Authorization") String authHeader) {
        String token = JwtUtil.extractToken(authHeader);
        String email = JwtUtil.getEmail(token);
        if (email == null) return unauthorized();

        try {
            Map<String, Object> data = JwtUtil.isAdmin(token)
                    ? authService.getAdminByEmail(email)
                    : authService.getUserByEmail(email);

            if (data == null) return notFound("Felhasználó nem található");
            return Response.ok(data).build();
        } catch (Exception e) {
            return serverError("Adatlekérés sikertelen: " + e.getMessage());
        }
    }

    @POST
    @Path("refresh")
    @Produces(MediaType.APPLICATION_JSON)
    public Response refresh(@HeaderParam("Authorization") String authHeader) {
        String token = JwtUtil.extractToken(authHeader);
        String email = JwtUtil.getEmail(token);
        if (email == null) return unauthorized();

        String role     = JwtUtil.getRole(token);
        String newToken = JwtUtil.generateToken(email, role != null ? role : "user");

        Map<String, Object> res = new LinkedHashMap<>();
        res.put("token", newToken);
        res.put("role",  role);
        return Response.ok(res).build();
    }

    @POST
    @Path("logout")
    @Produces(MediaType.APPLICATION_JSON)
    public Response logout() {
        return Response.ok("{\"message\": \"Sikeres kijelentkezés\"}").build();
    }

    // --- helpers ---
    private String s(Map<String, Object> b, String k) {
        Object v = b.get(k);
        return v != null ? v.toString().trim() : null;
    }
    private Map<String, Object> err(String msg) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("error", msg);
        return m;
    }
    private Response bad(String m)      { return Response.status(400).entity(err(m)).build(); }
    private Response conflict(String m) { return Response.status(409).entity(err(m)).build(); }
    private Response unauthorized()     { return Response.status(401).entity(err("Bejelentkezés szükséges")).build(); }
    private Response notFound(String m) { return Response.status(404).entity(err(m)).build(); }
    private Response serverError(String m) { return Response.status(500).entity(err(m)).build(); }
}
