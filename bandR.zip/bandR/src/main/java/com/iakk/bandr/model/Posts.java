/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iakk.bandr.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Lili
 */
@Entity
@Table(name = "posts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Posts.findAll", query = "SELECT p FROM Posts p"),
    @NamedQuery(name = "Posts.findByPostId", query = "SELECT p FROM Posts p WHERE p.postId = :postId"),
    @NamedQuery(name = "Posts.findByTitle", query = "SELECT p FROM Posts p WHERE p.title = :title"),
    @NamedQuery(name = "Posts.findByCreated", query = "SELECT p FROM Posts p WHERE p.created = :created"),
    @NamedQuery(name = "Posts.findByImageUrl", query = "SELECT p FROM Posts p WHERE p.imageUrl = :imageUrl"),
    @NamedQuery(name = "Posts.findByIsDeleted", query = "SELECT p FROM Posts p WHERE p.isDeleted = :isDeleted"),
    @NamedQuery(name = "Posts.findByDeletedAt", query = "SELECT p FROM Posts p WHERE p.deletedAt = :deletedAt")})
public class Posts implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "post_id")
    private Integer postId;
    @Size(max = 200)
    @Column(name = "title")
    private String title;
    @Lob
    @Size(max = 65535)
    @Column(name = "content")
    private String content;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Size(max = 200)
    @Column(name = "image_url")
    private String imageUrl;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "postId")
    private Collection<PostModeration> postModerationCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "postId")
    private Collection<SavedPosts> savedPostsCollection;
    @OneToMany(mappedBy = "postId")
    private Collection<PostLikes> postLikesCollection;
    @JoinColumn(name = "band_id", referencedColumnName = "band_id")
    @ManyToOne
    private Bands bandId;

    public Posts() {
    }

    public Posts(Integer postId) {
        this.postId = postId;
    }

    public Posts(Integer postId, Date created, boolean isDeleted) {
        this.postId = postId;
        this.created = created;
        this.isDeleted = isDeleted;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    @XmlTransient
    public Collection<PostModeration> getPostModerationCollection() {
        return postModerationCollection;
    }

    public void setPostModerationCollection(Collection<PostModeration> postModerationCollection) {
        this.postModerationCollection = postModerationCollection;
    }

    @XmlTransient
    public Collection<SavedPosts> getSavedPostsCollection() {
        return savedPostsCollection;
    }

    public void setSavedPostsCollection(Collection<SavedPosts> savedPostsCollection) {
        this.savedPostsCollection = savedPostsCollection;
    }

    @XmlTransient
    public Collection<PostLikes> getPostLikesCollection() {
        return postLikesCollection;
    }

    public void setPostLikesCollection(Collection<PostLikes> postLikesCollection) {
        this.postLikesCollection = postLikesCollection;
    }

    public Bands getBandId() {
        return bandId;
    }

    public void setBandId(Bands bandId) {
        this.bandId = bandId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (postId != null ? postId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Posts)) {
            return false;
        }
        Posts other = (Posts) object;
        if ((this.postId == null && other.postId != null) || (this.postId != null && !this.postId.equals(other.postId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.iakk.bandr.model.Posts[ postId=" + postId + " ]";
    }
    
}
