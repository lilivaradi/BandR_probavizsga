package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: GetAllPosts, GetPostById, GetPostsByBand, AddPost, UpdatePost, SoftDeletePosts
 */
@Stateless
public class PostsService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    public List<Map<String, Object>> findAll() throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetAllPosts()}");
             ResultSet rs = cs.executeQuery()) {
            List<Map<String, Object>> list = new ArrayList<>();
            while (rs.next()) list.add(mapFull(rs));
            return list;
        }
    }

    public Map<String, Object> findById(int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetPostById(?)}")) {
            cs.setInt(1, postId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapFull(rs) : null;
            }
        }
    }

    public List<Map<String, Object>> findByBand(int bandId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetPostsByBand(?)}")) {
            cs.setInt(1, bandId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("postId",  rs.getInt("post_id"));
                    row.put("title",   rs.getString("title"));
                    row.put("content", rs.getString("content"));
                    row.put("created", rs.getTimestamp("created"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** AddPost(band_id, title, content) */
    public void create(int bandId, String title, String content) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL AddPost(?, ?, ?)}")) {
            cs.setInt(1, bandId);
            cs.setString(2, title);
            cs.setString(3, content != null ? content : "");
            cs.executeUpdate();
        }
    }

    /** UpdatePost(post_id, title, content) */
    public void update(int postId, String title, String content) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL UpdatePost(?, ?, ?)}")) {
            cs.setInt(1, postId);
            cs.setString(2, title);
            cs.setString(3, content != null ? content : "");
            cs.executeUpdate();
        }
    }

    /** SoftDeletePosts(post_id) */
    public void delete(int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL SoftDeletePosts(?)}")) {
            cs.setInt(1, postId);
            cs.executeUpdate();
        }
    }

    private Map<String, Object> mapFull(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("postId",   rs.getInt("post_id"));
        row.put("bandId",   rs.getInt("band_id"));
        row.put("title",    rs.getString("title"));
        row.put("content",  rs.getString("content"));
        row.put("imageUrl", rs.getString("image_url"));
        row.put("created",  rs.getTimestamp("created"));
        return row;
    }
}
