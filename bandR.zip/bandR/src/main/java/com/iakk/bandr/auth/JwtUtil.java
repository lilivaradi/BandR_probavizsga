package com.iakk.bandr.auth;

import io.jsonwebtoken.*;
import java.util.Date;

/**
 * Szerepkörök: "user" és "admin" — semmi más.
 */
public class JwtUtil {

    private static final String SECRET = System.getenv("JWT_SECRET") != null
            ? System.getenv("JWT_SECRET")
            : "bandr-secret-key-minimum-32-chars-2024!";

    private static final long EXP_MS = 24 * 60 * 60 * 1000L; // 24 óra

    public static String generateToken(String email, String role) {
        long now = System.currentTimeMillis();
        try {
            return Jwts.builder()
                    .setSubject(email)
                    .claim("role", role)
                    .setIssuedAt(new Date(now))
                    .setExpiration(new Date(now + EXP_MS))
                    .signWith(SignatureAlgorithm.HS256, SECRET.getBytes("UTF-8"))
                    .compact();
        } catch (Exception e) {
            throw new RuntimeException("Token generálás sikertelen", e);
        }
    }

    public static String extractToken(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
        return authHeader.substring("Bearer ".length()).trim();
    }

    public static String getEmail(String token) {
        if (token == null) return null;
        try {
            return Jwts.parser()
                    .setSigningKey(SECRET.getBytes("UTF-8"))
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();
        } catch (Exception e) {
            return null;
        }
    }

    public static String getRole(String token) {
        if (token == null) return null;
        try {
            return Jwts.parser()
                    .setSigningKey(SECRET.getBytes("UTF-8"))
                    .parseClaimsJws(token)
                    .getBody()
                    .get("role", String.class);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isAdmin(String token) {
        return "admin".equalsIgnoreCase(getRole(token));
    }

    public static boolean isValid(String token) {
        return getEmail(token) != null;
    }
}
