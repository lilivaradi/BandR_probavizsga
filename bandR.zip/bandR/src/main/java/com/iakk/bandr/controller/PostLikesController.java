package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.PostLikesService;
import com.iakk.bandr.service.UsersService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("postlikes")
public class PostLikesController {

    @EJB private PostLikesService postLikesService;
    @EJB private UsersService     usersService;

    @GET
    @Path("count/{postId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCount(@PathParam("postId") Integer postId) {
        try {
            long count = postLikesService.countLikes(postId);
            return Response.ok("{\"count\": " + count + "}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("post/{postId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getByPost(@PathParam("postId") Integer postId) {
        try { return Response.ok(postLikesService.getLikes(postId)).build(); }
        catch (Exception e) { return serverError(e); }
    }

    @GET
    @Path("check/{postId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response hasLiked(@PathParam("postId") Integer postId,
                             @HeaderParam("Authorization") String authHeader) {
        Integer userId = resolveUserId(authHeader);
        if (userId == null) return unauthorized();
        try {
            boolean liked = postLikesService.hasLiked(postId, userId);
            return Response.ok("{\"hasLiked\": " + liked + "}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @POST
    @Path("toggle/{postId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response toggle(@PathParam("postId") Integer postId,
                           @HeaderParam("Authorization") String authHeader) {
        Integer userId = resolveUserId(authHeader);
        if (userId == null) return unauthorized();
        try {
            long count = postLikesService.toggle(postId, userId);
            return Response.ok("{\"count\": " + count + "}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private Integer resolveUserId(String authHeader) {
        String email = JwtUtil.getEmail(JwtUtil.extractToken(authHeader));
        if (email == null) return null;
        try { return usersService.findUserIdByEmail(email); }
        catch (Exception e) { return null; }
    }

    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
