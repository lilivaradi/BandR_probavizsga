package com.iakk.bandr.service;

import com.iakk.bandr.auth.AuthREST;
import com.iakk.bandr.controller.*;
import java.util.Set;
import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        resources.add(AuthREST.class);
        resources.add(UsersController.class);
        resources.add(ProfilesController.class);
        resources.add(BandsController.class);
        resources.add(PostsController.class);
        resources.add(PostLikesController.class);
        resources.add(SavedPostsController.class);
        resources.add(SamplesController.class);
        resources.add(MessagesController.class);
        resources.add(AdminController.class);
        return resources;
    }
}
