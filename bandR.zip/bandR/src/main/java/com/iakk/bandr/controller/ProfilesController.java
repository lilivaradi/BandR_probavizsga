package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.ProfilesService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("profiles")
public class ProfilesController {

    @EJB
    private ProfilesService profilesService;

    @GET
    @Path("{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getByUserId(@PathParam("userId") Integer userId) {
        try {
            Map<String, Object> profile = profilesService.findByUserId(userId);
            return profile != null ? Response.ok(profile).build() : notFound("Profil nem található");
        } catch (Exception e) { return serverError(e); }
    }

    @PUT
    @Path("{userId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("userId") Integer userId, Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            profilesService.update(
                userId,
                s(body, "bio"), s(body, "instruments"),
                s(body, "favGenres"), s(body, "location"),
                Boolean.TRUE.equals(body.get("lookingForBand")),
                Boolean.TRUE.equals(body.get("lookingForFans"))
            );
            return Response.ok("{\"message\": \"Profil sikeresen frissítve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    @DELETE
    @Path("{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("userId") Integer userId,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            profilesService.delete(userId);
            return Response.ok("{\"message\": \"Profil törölve\"}").build();
        } catch (Exception e) { return serverError(e); }
    }

    private boolean loggedIn(String h) { return JwtUtil.isValid(JwtUtil.extractToken(h)); }
    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
