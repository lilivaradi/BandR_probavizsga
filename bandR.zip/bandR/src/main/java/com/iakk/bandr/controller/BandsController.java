package com.iakk.bandr.controller;

import com.iakk.bandr.auth.JwtUtil;
import com.iakk.bandr.service.BandsService;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;

@Path("bands")
public class BandsController {

    @EJB
    private BandsService bandsService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        try {
            return Response.ok(bandsService.findAll()).build();
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Integer id) {
        try {
            Map<String, Object> band = bandsService.findById(id);
            return band != null ? Response.ok(band).build() : notFound("Banda nem található");
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        String name        = s(body, "name");
        String description = s(body, "description");
        Integer createdBy  = toInt(body.get("createdBy"));

        if (name == null || name.isEmpty()) return bad("A banda neve kötelező");
        if (createdBy == null)              return bad("A createdBy (userId) megadása kötelező");

        try {
            bandsService.create(name, description, createdBy);
            return Response.status(201).entity("{\"message\": \"Banda sikeresen létrehozva\"}").build();
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Integer id, Map<String, Object> body,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();

        String name        = s(body, "name");
        String description = s(body, "description");
        Integer createdBy  = toInt(body.get("createdBy"));

        if (name == null || name.isEmpty()) return bad("A banda neve kötelező");
        if (createdBy == null)              return bad("A createdBy megadása kötelező");

        try {
            bandsService.update(id, name, description, createdBy);
            return Response.ok("{\"message\": \"Banda sikeresen frissítve\"}").build();
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Integer id,
                           @HeaderParam("Authorization") String authHeader) {
        if (!loggedIn(authHeader)) return unauthorized();
        try {
            bandsService.delete(id);
            return Response.ok("{\"message\": \"Banda sikeresen törölve\"}").build();
        } catch (Exception e) {
            return serverError(e);
        }
    }

    private boolean loggedIn(String h) { return JwtUtil.isValid(JwtUtil.extractToken(h)); }
    private String s(Map<String, Object> b, String k) { Object v = b.get(k); return v != null ? v.toString().trim() : null; }
    private Integer toInt(Object v) {
        if (v == null) return null;
        if (v instanceof Integer) return (Integer) v;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return null; }
    }
    private Response unauthorized() { return Response.status(401).entity("{\"error\":\"Bejelentkezés szükséges\"}").build(); }
    private Response notFound(String m) { return Response.status(404).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response bad(String m) { return Response.status(400).entity("{\"error\":\"" + m + "\"}").build(); }
    private Response serverError(Exception e) { return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build(); }
}
