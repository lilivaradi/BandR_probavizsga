package com.iakk.bandr.service;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

/**
 * Tárolt eljárások: CountLikes, GetPostLikes, HasLiked, ToggleLike
 */
@Stateless
public class PostLikesService {

    @Resource(lookup = "java:/bandr_uj")
    private DataSource ds;

    /** CountLikes(post_id) — visszaadja a like darabszámot */
    public long countLikes(int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL CountLikes(?)}")) {
            cs.setInt(1, postId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? rs.getLong("total_likes") : 0;
            }
        }
    }

    /** GetPostLikes(post_id) — like-olók listája */
    public List<Map<String, Object>> getLikes(int postId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL GetPostLikes(?)}")) {
            cs.setInt(1, postId);
            try (ResultSet rs = cs.executeQuery()) {
                List<Map<String, Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("userId",  rs.getInt("user_id"));
                    row.put("created", rs.getTimestamp("created"));
                    list.add(row);
                }
                return list;
            }
        }
    }

    /** HasLiked(post_id, user_id) — likeolta-e a user? */
    public boolean hasLiked(int postId, int userId) throws SQLException {
        try (Connection con = ds.getConnection();
             CallableStatement cs = con.prepareCall("{CALL HasLiked(?, ?)}")) {
            cs.setInt(1, postId);
            cs.setInt(2, userId);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() && rs.getInt("has_liked") == 1;
            }
        }
    }

    /** ToggleLike(post_id, user_id) — like/unlike, visszaadja az új darabszámot */
    public long toggle(int postId, int userId) throws SQLException {
        try (Connection con = ds.getConnection()) {
            try (CallableStatement cs = con.prepareCall("{CALL ToggleLike(?, ?)}")) {
                cs.setInt(1, postId);
                cs.setInt(2, userId);
                cs.executeUpdate();
            }
            try (CallableStatement cs2 = con.prepareCall("{CALL CountLikes(?)}")) {
                cs2.setInt(1, postId);
                try (ResultSet rs = cs2.executeQuery()) {
                    return rs.next() ? rs.getLong("total_likes") : 0;
                }
            }
        }
    }
}
