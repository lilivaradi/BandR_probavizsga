const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    ENDPOINTS: {
        USERS: "/users",
        POSTS: "/posts"
    },
    APP: {
        LOGIN_PAGE: "../html/login.html"
    }
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    getAuthHeader() {
        const token = Auth.getToken();
        return token ? { "Authorization": `Bearer ${token}` } : {};
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.APP.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null) {
    const headers = {
        "Content-Type": "application/json",
        ...Auth.getAuthHeader()
    };

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 401) { Auth.logout(); throw new Error("Kérjük jelentkezz be újra."); }
    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
    return data;
}

function initSidebar() {
    const settingsBtn = document.getElementById('settings-btn');
    const sidebar = document.getElementById('sidebar');
    const closeSidebar = document.getElementById('close-sidebar');

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('active');
        document.body.classList.toggle('sidebar-open');
    });

    closeSidebar.addEventListener('click', () => {
        sidebar.classList.remove('active');
        document.body.classList.remove('sidebar-open');
    });

    document.addEventListener('click', (e) => {
        const clickedSettings = e.target.closest('#settings-btn');
        const clickedSidebar = e.target.closest('#sidebar');
        if (!clickedSidebar && !clickedSettings) {
            sidebar.classList.remove('active');
            document.body.classList.remove('sidebar-open');
        }
    });
}

function initMenuItems() {
    const menuItems = document.querySelectorAll('.admin-menu ul li');
    menuItems.forEach(item => {
        item.addEventListener('click', function () {
            menuItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function initUserSearch() {
    document.getElementById('user-search').addEventListener('input', function () {
        const term = this.value.toLowerCase();
        document.querySelectorAll('#users-table tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
        });
    });
}

function initDeleteButtons() {
    document.querySelectorAll('.row-btn-del').forEach(btn => {
        btn.addEventListener('click', async function () {
            const row = this.closest('tr');
            const name = row.querySelector('.user-cell').textContent.trim();
            const userId = row.dataset.userId;

            if (!confirm('Biztosan törölni szeretnéd: ' + name + '?')) return;

            try {
                if (userId) {
                    await apiRequest(`${CONFIG.ENDPOINTS.USERS}/${userId}`, "DELETE");
                }

                row.style.transition = 'opacity 0.4s';
                row.style.opacity = '0';
                setTimeout(() => row.remove(), 400);

            } catch (err) {
                console.error('Törlési hiba:', err);
                alert('Törlés sikertelen: ' + err.message);
            }
        });
    });
}

// document.addEventListener('DOMContentLoaded', () => {
//     if (!Auth.isAuthenticated()) {
//         window.location.href = CONFIG.APP.LOGIN_PAGE;
//         return;
//     }

//     initSidebar();
//     initMenuItems();
//     initUserSearch();
//     initDeleteButtons();
// });