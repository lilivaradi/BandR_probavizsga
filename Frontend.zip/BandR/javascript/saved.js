const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    ENDPOINTS: {
        SAVED: "/saved",
        POST_LIKES: "/postlikes"
    },
    APP: {
        LOGIN_PAGE: "../html/login.html"
    }
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    getUserId() {
        return JSON.parse(localStorage.getItem("user") || "{}").userId ?? null;
    },

    getAuthHeader() {
        const token = Auth.getToken();
        return token ? { "Authorization": `Bearer ${token}` } : {};
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.APP.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null) {
    const headers = {
        "Content-Type": "application/json",
        ...Auth.getAuthHeader()
    };

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 401) { Auth.logout(); throw new Error("Kérjük jelentkezz be újra."); }
    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
    return data;
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.getElementById('settings-btn');
    const body = document.body;

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('active');
        body.classList.toggle('sidebar-open');
    });

    body.addEventListener('click', (e) => {
        const clickedSettings = e.target.closest('#settings-btn');
        const clickedSidebar = e.target.closest('#sidebar');
        if (body.classList.contains('sidebar-open') && !clickedSidebar && !clickedSettings) {
            sidebar.classList.remove('active');
            body.classList.remove('sidebar-open');
        }
    });
}

function loadSavedBands() {
    const savedBands = JSON.parse(localStorage.getItem('savedBands') || '[]');
    const container = document.getElementById('saved-bands-container');

    savedBands.forEach(band => {
        const bandCard = document.createElement('div');
        bandCard.className = 'text-box1';
        bandCard.innerHTML = `
            <div class="content-wrapper">
                <h2>${band.name}</h2>
                <p>${band.description}</p>
                <div class="extra-content">
                    <p>
                        You liked this band! They're looking for talented musicians to join their group.
                        Make sure to reach out to them and show your interest. This could be the perfect
                        opportunity to join a great band and create amazing music together.
                    </p>
                </div>
            </div>
            <div class="img-wrapper">
                <img src="${band.image}" alt="${band.name}">
            </div>
        `;
        container.appendChild(bandCard);
    });
}

async function loadSavedPosts() {
    const container = document.querySelector('.posts-container') || document.querySelector('.container-fluid');
    if (!container) return;

    try {
        const userId = Auth.getUserId();
        if (!userId) return;

        const savedData = await apiRequest(`${CONFIG.ENDPOINTS.SAVED}?userId=${userId}`);
        if (!Array.isArray(savedData) || savedData.length === 0) return;

        savedData.forEach(post => {
            const postEl = container.querySelector(`[data-post-id="${post.postId ?? post.id}"]`);
            if (postEl) {
                const saveBtn = postEl.querySelector('.save-btn');
                if (saveBtn) {
                    saveBtn.classList.add('saved');
                    saveBtn.querySelector('ion-icon')?.setAttribute('name', 'bookmark');
                    const span = saveBtn.querySelector('span');
                    if (span) span.textContent = 'Saved';
                }
            }
        });
    } catch (err) {
        console.warn('Saved posztok betöltési hiba:', err.message);
    }
}

function initPostButtons() {
    document.querySelectorAll('.text-box1').forEach(post => {
        const postId = post.dataset.postId;
        const likeBtn = post.querySelector('.like-btn');
        const saveBtn = post.querySelector('.save-btn');
        const likeCount = post.querySelector('.like-count');

        if (!postId || !likeBtn || !saveBtn) return;

        likeBtn._liked = likeBtn.classList.contains('liked');
        saveBtn._saved = saveBtn.classList.contains('saved');

        likeBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const liked = likeBtn._liked;
            const icon = likeBtn.querySelector('ion-icon');
            let count = parseInt(likeCount.textContent) || 0;

            if (liked) {
                icon.setAttribute('name', 'heart-outline');
                likeBtn.classList.remove('liked');
                likeCount.textContent = `${Math.max(0, count - 1)} Likes`;
                likeBtn._liked = false;
            } else {
                icon.setAttribute('name', 'heart');
                likeBtn.classList.add('liked');
                likeCount.textContent = `${count + 1} Likes`;
                likeBtn._liked = true;
            }

            try {
                if (liked) {
                    await apiRequest(`${CONFIG.ENDPOINTS.POST_LIKES}/${postId}`, "DELETE");
                } else {
                    await apiRequest(CONFIG.ENDPOINTS.POST_LIKES, "POST", {
                        postId: Number(postId),
                        userId: Auth.getUserId()
                    });
                }
            } catch (err) {
                console.error('Like hiba:', err);
            }
        });

        saveBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const saved = saveBtn._saved;
            const icon = saveBtn.querySelector('ion-icon');
            const textSpan = saveBtn.querySelector('span');

            if (saved) {
                icon.setAttribute('name', 'bookmark-outline');
                saveBtn.classList.remove('saved');
                textSpan.textContent = 'Save';
                saveBtn._saved = false;
            } else {
                icon.setAttribute('name', 'bookmark');
                saveBtn.classList.add('saved');
                textSpan.textContent = 'Saved';
                saveBtn._saved = true;
            }

            try {
                if (saved) {
                    await apiRequest(`${CONFIG.ENDPOINTS.SAVED}/${postId}`, "DELETE");
                } else {
                    await apiRequest(CONFIG.ENDPOINTS.SAVED, "POST", {
                        postId: Number(postId),
                        userId: Auth.getUserId()
                    });
                }
            } catch (err) {
                console.error('Save hiba:', err);
            }
        });
    });
}

// document.addEventListener('DOMContentLoaded', () => {
//     if (!Auth.isAuthenticated()) {
//         window.location.href = CONFIG.APP.LOGIN_PAGE;
//         return;
//     }

//     initSidebar();
//     loadSavedBands();
//     initPostButtons();
//     loadSavedPosts();
// });