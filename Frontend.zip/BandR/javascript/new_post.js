const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    ENDPOINTS: {
        POSTS: "/posts"
    },
    APP: {
        LOGIN_PAGE: "../html/login.html",
        YOUR_POSTS_PAGE: "../html/your_posts.html"
    }
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    getUserId() {
        return JSON.parse(localStorage.getItem("user") || "{}").userId ?? null;
    },

    getAuthHeader() {
        const token = Auth.getToken();
        return token ? { "Authorization": `Bearer ${token}` } : {};
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.APP.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null, isFormData = false) {
    const headers = { ...Auth.getAuthHeader() };
    if (!isFormData) headers["Content-Type"] = "application/json";

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: isFormData ? body : body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 401) { Auth.logout(); throw new Error("Kérjük jelentkezz be újra."); }
    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
    return data;
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.getElementById('settings-btn');
    const body = document.body;

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('active');
        body.classList.toggle('sidebar-open');
    });

    body.addEventListener('click', (e) => {
        const clickedSettings = e.target.closest('#settings-btn');
        const clickedSidebar = e.target.closest('#sidebar');
        if (body.classList.contains('sidebar-open') && !clickedSidebar && !clickedSettings) {
            sidebar.classList.remove('active');
            body.classList.remove('sidebar-open');
        }
    });

    document.querySelector('.sidebar-icon').addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    });
}

function initPreview() {
    const titleInput = document.getElementById('postTitle');
    const descriptionInput = document.getElementById('postDescription');
    const imageInput = document.getElementById('postImage');

    const previewTitle = document.getElementById('previewTitle');
    const previewDescription = document.getElementById('previewDescription');
    const previewImage = document.getElementById('previewImage');
    const previewBox = document.querySelector('.text-box1-preview');

    titleInput.addEventListener('input', (e) => {
        previewTitle.textContent = e.target.value || 'A poszt címe itt jelenik meg';
    });

    descriptionInput.addEventListener('input', (e) => {
        previewDescription.textContent = e.target.value || 'A rövid leírás itt lesz látható...';
    });

    imageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            previewImage.src = event.target.result;
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = `<img src="${event.target.result}" alt="preview">`;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    });

    previewBox.addEventListener('click', () => {
        previewBox.classList.toggle('expanded');
    });
}

function initForm() {
    const form = document.getElementById('newPostForm');
    const titleInput = document.getElementById('postTitle');
    const descInput = document.getElementById('postDescription');
    const contactInput = document.getElementById('contactInfo');
    const imageInput = document.getElementById('postImage');
    const error = document.getElementById('errorMessage');
    const button = form.querySelector("button[type='submit']");

    function showError(msg) {
        error.textContent = msg;
        error.style.display = "block";
    }

    function hideError() {
        error.style.display = "none";
        error.textContent = "";
    }

    function validate(title, description) {
        if (!title) return "A cím megadása kötelező";
        if (!description) return "A leírás megadása kötelező";
        return null;
    }

    async function submit(e) {
        e.preventDefault();

        const title = titleInput.value.trim();
        const description = descInput.value.trim();
        const contactInfo = contactInput ? contactInput.value.trim() : "";
        const imageFile = imageInput.files[0];

        const validationError = validate(title, description);
        if (validationError) { showError(validationError); return; }

        hideError();

        const originalHTML = button.innerHTML;
        button.disabled = true;
        button.textContent = "Közzététel folyamatban...";

        try {
            if (imageFile) {
                const formData = new FormData();
                formData.append("title", title);
                formData.append("description", description);
                formData.append("userId", Auth.getUserId());
                if (contactInfo) formData.append("contactInfo", contactInfo);
                formData.append("image", imageFile, imageFile.name);
                await apiRequest(CONFIG.ENDPOINTS.POSTS, "POST", formData, true);
            } else {
                const body = {
                    title,
                    description,
                    userId: Auth.getUserId(),
                    ...(contactInfo && { contactInfo })
                };
                await apiRequest(CONFIG.ENDPOINTS.POSTS, "POST", body);
            }

            window.location.href = CONFIG.APP.YOUR_POSTS_PAGE;

        } catch (err) {
            showError(err.message);
            button.disabled = false;
            button.innerHTML = originalHTML;
        }
    }

    form.addEventListener('submit', submit);
    titleInput.addEventListener('input', hideError);
    descInput.addEventListener('input', hideError);
}

// document.addEventListener('DOMContentLoaded', () => {
//     if (!Auth.isAuthenticated()) {
//         window.location.href = CONFIG.APP.LOGIN_PAGE;
//         return;
//     }

//     initSidebar();
//     initPreview();
//     initForm();
// });