const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    ENDPOINTS: {
        POSTS: "/posts",
        POST_LIKES: "/postlikes",
        SAVED: "/saved",
    },
    APP: {
        LOGIN_PAGE: "../html/login.html"
    }
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    getUserId() {
        return JSON.parse(localStorage.getItem("user") || "{}").userId ?? null;
    },

    getAuthHeader() {
        const token = Auth.getToken();
        return token ? { "Authorization": `Bearer ${token}` } : {};
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.APP.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null) {
    const headers = {
        "Content-Type": "application/json",
        ...Auth.getAuthHeader()
    };

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 401) {
        Auth.logout();
        throw new Error("Kérjük jelentkezz be újra.");
    }
    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
    return data;
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.getElementById('settings-btn');
    const body = document.body;

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('active');
        body.classList.toggle('sidebar-open');
    });

    body.addEventListener('click', (e) => {
        const clickedSettings = e.target.closest('#settings-btn');
        const clickedSidebar = e.target.closest('#sidebar');
        if (body.classList.contains('sidebar-open') && !clickedSidebar && !clickedSettings) {
            sidebar.classList.remove('active');
            body.classList.remove('sidebar-open');
        }
    });

    document.querySelector('.sidebar-icon').addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    });
}

function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function createPostElement(post, liked = false, saved = false) {
    const div = document.createElement('div');
    div.classList.add('text-box1');
    div.dataset.postId = post.postId ?? post.id;

    const imgSrc = post.imageUrl || post.image || `../kepek/band1.jpg`;

    div.innerHTML = `
        <div class="text-box1-main">
            <div class="content-wrapper">
                <h2>${escapeHtml(post.title)}</h2>
                <p>${escapeHtml(post.description ?? post.content)}</p>
            </div>
            <div class="img-wrapper">
                <img src="${escapeHtml(imgSrc)}" alt="${escapeHtml(post.title)}"
                     onerror="this.src='../kepek/band1.jpg'">
            </div>
        </div>
        <div class="post-actions">
            <button class="action-btn like-btn ${liked ? 'liked' : ''}">
                <ion-icon name="${liked ? 'heart' : 'heart-outline'}"></ion-icon>
                <span class="like-count">${post.likeCount ?? 0} Likes</span>
            </button>
            <button class="action-btn save-btn ${saved ? 'saved' : ''}">
                <ion-icon name="${saved ? 'bookmark' : 'bookmark-outline'}"></ion-icon>
                <span>${saved ? 'Saved' : 'Save'}</span>
            </button>
            <button class="action-btn message-btn">
                <ion-icon name="chatbubble-outline"></ion-icon>
                <a href="../html/messages.html"><span>Message</span></a>
            </button>
        </div>
    `;

    return div;
}

async function handleLike(postId, btn) {
    const liked = btn._liked;
    const icon = btn.querySelector('ion-icon');
    const countSpan = btn.querySelector('.like-count');
    let count = parseInt(countSpan.textContent) || 0;

    if (liked) {
        icon.setAttribute('name', 'heart-outline');
        btn.classList.remove('liked');
        countSpan.textContent = `${Math.max(0, count - 1)} Likes`;
        btn._liked = false;
    } else {
        icon.setAttribute('name', 'heart');
        btn.classList.add('liked');
        countSpan.textContent = `${count + 1} Likes`;
        btn._liked = true;
    }

    try {
        if (liked) {
            await apiRequest(`${CONFIG.ENDPOINTS.POST_LIKES}/${postId}`, "DELETE");
        } else {
            await apiRequest(CONFIG.ENDPOINTS.POST_LIKES, "POST", {
                postId: Number(postId),
                userId: Auth.getUserId()
            });
        }
    } catch (err) {
        console.error('Like hiba:', err);
    }
}

async function handleSave(postId, btn) {
    const saved = btn._saved;
    const icon = btn.querySelector('ion-icon');
    const textSpan = btn.querySelector('span');

    if (saved) {
        icon.setAttribute('name', 'bookmark-outline');
        btn.classList.remove('saved');
        textSpan.textContent = 'Save';
        btn._saved = false;
    } else {
        icon.setAttribute('name', 'bookmark');
        btn.classList.add('saved');
        textSpan.textContent = 'Saved';
        btn._saved = true;
    }

    try {
        if (saved) {
            await apiRequest(`${CONFIG.ENDPOINTS.SAVED}/${postId}`, "DELETE");
        } else {
            await apiRequest(CONFIG.ENDPOINTS.SAVED, "POST", {
                postId: Number(postId),
                userId: Auth.getUserId()
            });
        }
    } catch (err) {
        console.error('Save hiba:', err);
    }
}

function attachPostEvents(postEl) {
    const postId = postEl.dataset.postId;
    const likeBtn = postEl.querySelector('.like-btn');
    const saveBtn = postEl.querySelector('.save-btn');

    likeBtn._liked = likeBtn.classList.contains('liked');
    saveBtn._saved = saveBtn.classList.contains('saved');

    likeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        handleLike(postId, likeBtn);
    });

    saveBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        handleSave(postId, saveBtn);
    });
}

async function loadPosts() {
    const container = document.querySelector('.container-fluid');
    container.querySelectorAll('.text-box1').forEach(el => el.remove());

    const loader = document.createElement('div');
    loader.id = 'posts-loader';
    loader.style.cssText = 'text-align:center;padding:2rem;color:#aaa;font-size:1.1rem;';
    loader.textContent = 'Posztok betöltése...';
    container.appendChild(loader);

    try {
        const posts = await apiRequest(CONFIG.ENDPOINTS.POSTS);

        let likedIds = new Set();
        let savedIds = new Set();

        try {
            const userId = Auth.getUserId();
            if (userId) {
                const [likedData, savedData] = await Promise.all([
                    apiRequest(`${CONFIG.ENDPOINTS.POST_LIKES}?userId=${userId}`),
                    apiRequest(`${CONFIG.ENDPOINTS.SAVED}?userId=${userId}`)
                ]);
                if (Array.isArray(likedData))
                    likedIds = new Set(likedData.map(l => String(l.postId ?? l.id)));
                if (Array.isArray(savedData))
                    savedIds = new Set(savedData.map(s => String(s.postId ?? s.id)));
            }
        } catch (innerErr) {
            console.warn('Liked/saved listák nem elérhetők:', innerErr.message);
        }

        loader.remove();

        if (!Array.isArray(posts) || posts.length === 0) {
            const empty = document.createElement('p');
            empty.style.cssText = 'text-align:center;padding:2rem;color:#aaa;';
            empty.textContent = 'Még nincsenek posztok.';
            container.appendChild(empty);
            return;
        }

        posts.forEach(post => {
            const id = String(post.postId ?? post.id);
            const postEl = createPostElement(post, likedIds.has(id), savedIds.has(id));
            container.appendChild(postEl);
            attachPostEvents(postEl);
        });

    } catch (err) {
        loader.remove();
        console.error('Posztok betöltési hiba:', err);

        const errDiv = document.createElement('div');
        errDiv.style.cssText = 'text-align:center;padding:2rem;color:#e55;';
        errDiv.innerHTML = `
            <p>Nem sikerült betölteni</p>
            <small>${escapeHtml(err.message)}</small><br><br>
            <button onclick="loadPosts()" style="padding:.5rem 1.2rem;cursor:pointer;border-radius:6px;">
                Újrapróbálás
            </button>
        `;
        container.appendChild(errDiv);
    }
}

// document.addEventListener('DOMContentLoaded', () => {
//     if (!Auth.isAuthenticated()) {
//         window.location.href = CONFIG.APP.LOGIN_PAGE;
//         return;
//     }

//     initSidebar();
//     loadPosts();
// });