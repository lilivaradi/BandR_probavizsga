const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const textBoxes = document.querySelectorAll('.text-box1');

textBoxes.forEach(box => {
    box.addEventListener('click', () => {
        textBoxes.forEach(otherBox => {
            if (otherBox !== box) {
                otherBox.classList.remove('expanded');
            }
        });

        box.classList.toggle('expanded');
    });
});

const sidebarClose = document.getElementById('sidebar-close');

sidebarClose.addEventListener('click', (e) => {
    e.stopPropagation();
    sidebar.classList.remove('active');
    body.classList.remove('sidebar-open');
});

/*--------------------------------------------------------------------------- CRAUSEL ---------------------------------------------------------- */

const bands = [
    {
        name: "ZZ TOP",
        description: "We are looking for a vocalist",
        image: "../kepek/findband2.jpg"
    },
    {
        name: "ZZ Ward",
        description: "We need a drummer for our tour",
        image: "../kepek/findband3.jpg"
    },
    {
        name: "Foo Fighters",
        description: "Searching for a bassist in our band",
        image: "../kepek/findband1.jpg"
    },
    {
        name: "Rolling Stone",
        description: "Searching for a bassist in our band",
        image: "../kepek/findband4.jpg"
    },
    {
        name: "AC/DC",
        description: "Searching for a bassist in our band",
        image: "../kepek/findband5.jpeg"
    },
    {
        name: "Metallica",
        description: "Looking for a lead guitarist",
        image: "../kepek/findband2.jpg"
    },
    {
        name: "Queen",
        description: "Need a talented keyboardist",
        image: "../kepek/findband3.jpg"
    },
    {
        name: "The Beatles",
        description: "Searching for rhythm guitarist",
        image: "../kepek/findband1.jpg"
    },
    {
        name: "Pink Floyd",
        description: "Looking for creative drummer",
        image: "../kepek/findband4.jpg"
    },
    {
        name: "Led Zeppelin",
        description: "Need experienced bass player",
        image: "../kepek/findband5.jpeg"
    }
];

let currentIndex = 0;
let availableBands = [...bands];
let displayedBands = [];
const track = document.getElementById('carouselTrack');
const dotsContainer = document.getElementById('progressDots');

function createCard(band, index) {
    const card = document.createElement('div');
    card.className = 'band-card';
    card.dataset.bandIndex = index;
    card.dataset.bandName = band.name;
    card.innerHTML = `
        <div class="card-content">
            <div class="band-image-wrapper">
                <img src="${band.image}" alt="${band.name}" class="band-image">
            </div>
            <div class="band-info">
                <h2>${band.name}</h2>
                <p>${band.description}</p>
            </div>
            <div class="button-row">
                <button class="like" data-index="${index}">Like</button>
                <button class="pass" data-index="${index}">Pass</button>
            </div>
        </div>
    `;
    return card;
}

function getNextBand() {
    if (availableBands.length === 0) {
        return null;
    }
    return availableBands.shift();
}

function addNewCard() {
    const nextBand = getNextBand();
    if (!nextBand) return;

    const newIndex = displayedBands.length;
    displayedBands.push(nextBand);

    const newCard = createCard(nextBand, newIndex);
    track.appendChild(newCard);

    return newCard;
}

function createDots() {
    dotsContainer.innerHTML = '';
    const visibleBands = track.querySelectorAll('.band-card:not(.removed)');
    visibleBands.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.className = `dot ${index === currentIndex ? 'active' : ''}`;
        dot.addEventListener('click', () => goToSlide(index));
        dotsContainer.appendChild(dot);
    });
}

function updateCarousel() {
    const cards = Array.from(track.querySelectorAll('.band-card:not(.removed)'));
    const total = cards.length;

    if (total === 0) return;

    const half = Math.floor(total / 2);

    cards.forEach((card, index) => {
        card.className = 'band-card';

        let position = index - currentIndex;

        if (position > half) position -= total;
        if (position < -half) position += total;

        if (position === 0) {
            card.classList.add('active');
        } else if (position === -1) {
            card.classList.add('left-1');
        } else if (position === -2) {
            card.classList.add('left-2');
        } else if (position === 1) {
            card.classList.add('right-1');
        } else if (position === 2) {
            card.classList.add('right-2');
        }
    });

    const dots = dotsContainer.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentIndex);
    });
}

function goToSlide(index) {
    currentIndex = index;
    updateCarousel();
}

function nextSlide() {
    const visibleCards = track.querySelectorAll('.band-card:not(.removed)');
    currentIndex = (currentIndex + 1) % visibleCards.length;
    updateCarousel();
}

function prevSlide() {
    const visibleCards = track.querySelectorAll('.band-card:not(.removed)');
    currentIndex = (currentIndex - 1 + visibleCards.length) % visibleCards.length;
    updateCarousel();
}

function saveBandToLocalStorage(band) {
    let savedBands = JSON.parse(localStorage.getItem('savedBands') || '[]');

    const alreadySaved = savedBands.some(saved => saved.name === band.name);
    if (!alreadySaved) {
        savedBands.push(band);
        localStorage.setItem('savedBands', JSON.stringify(savedBands));
    }
}

function removeCardWithRotation(index) {
    const card = document.querySelector(`[data-band-index="${index}"]`);
    if (!card) return;

    nextSlide();

    setTimeout(() => {
        card.classList.add('removed');
        card.style.display = 'none';

        addNewCard();

        const visibleCards = track.querySelectorAll('.band-card:not(.removed)');
        if (visibleCards.length > 0) {
            currentIndex = Math.min(currentIndex, visibleCards.length - 1);
            createDots();
            updateCarousel();
        }
    }, 600);
}

function removeCardForLike(index) {
    const card = document.querySelector(`[data-band-index="${index}"]`);
    if (!card) return;

    card.style.transition = 'all 0.4s ease';
    card.style.opacity = '0';
    card.style.transform = 'scale(0.8)';

    setTimeout(() => {
        card.classList.add('removed');
        card.style.display = 'none';

        addNewCard();

        const visibleCards = track.querySelectorAll('.band-card:not(.removed)');
        if (visibleCards.length > 0) {
            currentIndex = Math.min(currentIndex, visibleCards.length - 1);
            updateCarousel();
            createDots();
        }
    }, 400);
}

for (let i = 0; i < 5 && i < bands.length; i++) {
    const band = availableBands.shift();
    displayedBands.push(band);
    track.appendChild(createCard(band, i));
}

createDots();
updateCarousel();

track.addEventListener('click', (e) => {
    if (e.target.classList.contains('like')) {
        const index = parseInt(e.target.dataset.index);
        const bandName = e.target.closest('.band-card').dataset.bandName;
        const band = displayedBands.find(b => b.name === bandName);
        if (band) {
            saveBandToLocalStorage(band);
        }
        removeCardForLike(index);
    } else if (e.target.classList.contains('pass')) {
        const index = parseInt(e.target.dataset.index);
        removeCardWithRotation(index);
    }
});

document.getElementById('prevBtn').addEventListener('click', prevSlide);
document.getElementById('nextBtn').addEventListener('click', nextSlide);

document.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft') prevSlide();
    if (e.key === 'ArrowRight') nextSlide();
});

let touchStartX = 0;

track.addEventListener('touchstart', e => {
    touchStartX = e.changedTouches[0].screenX;
});

track.addEventListener('touchend', e => {
    const touchEndX = e.changedTouches[0].screenX;
    if (touchStartX - touchEndX > 50) nextSlide();
    if (touchEndX - touchStartX > 50) prevSlide();
});