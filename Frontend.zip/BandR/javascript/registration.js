const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    REGISTER_ENDPOINT: "/auth/register",
    LOGIN_PAGE: "../html/login.html",
    TOKEN_REFRESH_INTERVAL: 45
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!this.getToken();
    }
};

async function apiRequest(endpoint, method = "GET", body = null) {
    const headers = {
        "Content-Type": "application/json"
    };

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);

    if (!response.ok) {
        throw new Error(data?.error || "Sikertelen kérés");
    }

    return data;
}

function initBackgroundSlider() {
    const images = [
        "../kepek/kep1.jpg",
        "../kepek/kep2.jpg",
        "../kepek/kep3.jpg"
    ];

    let index = 0;
    const leftPanel = document.querySelector(".left-panel");
    if (!leftPanel) return;

    leftPanel.style.setProperty("--bg-image", `url('${images[0]}')`);

    setInterval(() => {
        index = (index + 1) % images.length;
        leftPanel.style.setProperty("--bg-image", `url('${images[index]}')`);
    }, 3000);
}

function initRegistrationPage() {
    if (Auth.isAuthenticated()) {
        window.location.href = CONFIG.LOGIN_PAGE;
        return;
    }

    const form = document.getElementById("registrationForm");
    const username = document.getElementById("username");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const error = document.getElementById("errorMessage");
    const success = document.getElementById("successMessage");
    const button = form.querySelector("button[type='submit']");

    function showError(msg) {
        error.textContent = msg;
        error.style.display = "block";
        success.style.display = "none";
    }

    function showSuccess(msg) {
        success.textContent = msg;
        success.style.display = "block";
        error.style.display = "none";
    }

    function hideMessages() {
        error.style.display = "none";
        success.style.display = "none";
    }

    function validate(usernameVal, emailVal, passwordVal) {
        if (!usernameVal) return "A felhasználónév megadása kötelező";
        if (!emailVal) return "Az email cím megadása kötelező";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) return "Érvénytelen email cím";
        if (!passwordVal) return "A jelszó megadása kötelező";
        if (passwordVal.length < 6) return "A jelszónak legalább 6 karakter hosszúnak kell lennie";
        return null;
    }

    async function submit(e) {
        e.preventDefault();

        const usernameVal = username.value.trim();
        const emailVal = email.value.trim();
        const passwordVal = password.value;

        const validationError = validate(usernameVal, emailVal, passwordVal);
        if (validationError) {
            showError(validationError);
            return;
        }

        hideMessages();

        const originalText = button.textContent;
        button.disabled = true;
        button.textContent = "Regisztráció folyamatban...";

        try {
            await apiRequest(
                CONFIG.REGISTER_ENDPOINT,
                "POST",
                { username: usernameVal, email: emailVal, password: passwordVal }
            );

            showSuccess("Sikeres regisztráció! Átirányítás...");

            setTimeout(() => {
                window.location.href = CONFIG.LOGIN_PAGE;
            }, 2000);

        } catch (err) {
            showError(err.message);
            button.disabled = false;
            button.textContent = originalText;
        }
    }

    form.addEventListener("submit", submit);
    username.addEventListener("input", hideMessages);
    email.addEventListener("input", hideMessages);
    password.addEventListener("input", hideMessages);
}

document.addEventListener("DOMContentLoaded", () => {
    initBackgroundSlider();
    initRegistrationPage();
});