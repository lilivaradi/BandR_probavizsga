const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    ENDPOINTS: {
        PROFILE: "/profiles"
    },
    APP: {
        LOGIN_PAGE: "../html/login.html"
    }
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    getUserId() {
        return JSON.parse(localStorage.getItem("user") || "{}").userId ?? null;
    },

    getAuthHeader() {
        const token = Auth.getToken();
        return token ? { "Authorization": `Bearer ${token}` } : {};
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.APP.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null) {
    const headers = {
        "Content-Type": "application/json",
        ...Auth.getAuthHeader()
    };

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 401) { Auth.logout(); throw new Error("Kérjük jelentkezz be újra."); }
    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
    return data;
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.getElementById('settings-btn');
    const body = document.body;

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('active');
        body.classList.toggle('sidebar-open');
    });

    body.addEventListener('click', (e) => {
        const clickedSettings = e.target.closest('#settings-btn');
        const clickedSidebar = e.target.closest('#sidebar');
        if (body.classList.contains('sidebar-open') && !clickedSidebar && !clickedSettings) {
            sidebar.classList.remove('active');
            body.classList.remove('sidebar-open');
        }
    });

    document.querySelector('.sidebar-icon').addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    });
}

function initExpandableBoxes() {
    const textBoxes = document.querySelectorAll('.text-box1');

    textBoxes.forEach(box => {
        box.addEventListener('click', () => {
            textBoxes.forEach(otherBox => {
                if (otherBox !== box) otherBox.classList.remove('expanded');
            });
            box.classList.toggle('expanded');
        });
    });
}

async function loadProfile() {
    const userId = Auth.getUserId();
    if (!userId) return;

    try {
        const profile = await apiRequest(`${CONFIG.ENDPOINTS.PROFILE}/${userId}`);
        if (!profile) return;

        const usernameEl = document.getElementById('profile-username');
        const bioEl = document.getElementById('profile-bio');
        const emailEl = document.getElementById('profile-email');

        if (usernameEl) usernameEl.textContent = profile.username ?? "";
        if (bioEl) bioEl.textContent = profile.bio ?? "";
        if (emailEl) emailEl.textContent = profile.email ?? "";

    } catch (err) {
        console.warn('Profil betöltési hiba:', err.message);
    }
}

// document.addEventListener('DOMContentLoaded', () => {
//     if (!Auth.isAuthenticated()) {
//         window.location.href = CONFIG.APP.LOGIN_PAGE;
//         return;
//     }

//     initSidebar();
//     initExpandableBoxes();
//     loadProfile();
// });