describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://127.0.0.1:5500/html/registration.html')
  })
});

it('Registration', function() {
  cy.visit('http://127.0.0.1:5500/html/registration.html')
  cy.get('#firstName').click();
  cy.get('#firstName').type('Lévay');
  cy.get('#lastName').click();
  cy.get('#lastName').type('Botond');
  cy.get('#username').click();
  cy.get('#username').type('levayb2006');
  cy.get('#email').click();
  cy.get('#email').type('levaybodri');
  cy.get('#email').type('@gmail.com');
  cy.get('#password').click();
  cy.get('#password').type('levayb2006');
  cy.get('#registrationForm button.create-btn').click();
  
});

it('Login', function() {
  cy.visit('http://127.0.0.1:5500/html/login.html')
  cy.get('#email').click();
  cy.get('#email').type('levaybodri@gmail.com');
  cy.get('#loginForm').click();
  cy.get('#password').click();
  cy.get('#password').type('levayb2006');
  cy.get('#loginForm button.create-btn').click();
  
});

it('RegistrationFailed', function() {
  cy.visit('http://127.0.0.1:5500/html/registration.html')
  cy.get('#firstName').click();
  cy.get('#firstName').type('Lévay');
  cy.get('#lastName').click();
  cy.get('#lastName').type('Botond');
  cy.get('#username').click();
  cy.get('#username').type('levayb2006');
  cy.get('#registrationForm').click();
  cy.get('#email').click();
  cy.get('#email').type('levaybodri@gmail.com');
  cy.get('#password').click();
  cy.get('#password').type('levayb37');
  cy.get('#registrationForm button.create-btn').click();
  
});

it('LoginFailed', function() {
  cy.visit('http://127.0.0.1:5500/html/login.html')
  cy.get('#email').click();
  cy.get('#email').type('levaybodri@gmail.com');
  cy.get('#password').click();
  cy.get('#password').type('123');
  cy.get('#loginForm button.create-btn').click();
  cy.get('#errorMessage').should('have.class', 'error-message');
  cy.get('#errorMessage').should('have.class', 'error-message');
});

it('IncompleteRegistration', function() {
  cy.visit('http://127.0.0.1:5500/html/registration.html')
  cy.get('#firstName').click();
  cy.get('#firstName').type('Lévay');
  cy.get('#lastName').click();
  cy.get('#lastName').type('Botond');
  cy.get('#username').click();
  cy.get('#username').type('levayb2006');
  cy.get('#email').click();
  cy.get('#email').type('levaybodri@gmial.com');
  cy.get('#registrationForm button.create-btn').click();
  
});

it('IncompleteLogin', function() {
  cy.visit('http://127.0.0.1:5500/html/login.html')
  cy.get('#email').click();
  cy.get('#email').type('levaybodri@gmail.com');
  cy.get('#loginForm button.create-btn').click();
  
});