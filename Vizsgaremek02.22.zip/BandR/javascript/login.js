const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr-1.0-SNAPSHOT/webresources",
    LOGIN_ENDPOINT: "/auth/login",
    HOME_PAGE: "../html/home.html",
    LOGIN_PAGE: "../html/login.html",
    TOKEN_REFRESH_INTERVAL: 45
};

const Auth = {
    getToken() {
        return localStorage.getItem("token");
    },

    isAuthenticated() {
        return !!Auth.getToken();
    },

    save(data) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify({
            userId: data.userId,
            username: data.username,
            email: data.email
        }));
    },

    clear() {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
    },

    logout() {
        Auth.clear();
        window.location.href = CONFIG.LOGIN_PAGE;
    }
};

async function apiRequest(endpoint, method = "GET", body = null, auth = true) {
    const headers = {
        "Content-Type": "application/json"
    };

    if (auth && Auth.getToken()) {
        headers["Authorization"] = `Bearer ${Auth.getToken()}`;
    }

    let response;
    try {
        response = await fetch(CONFIG.BASE_URL + endpoint, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null
        });
    } catch (networkError) {
        throw new Error("A szerver nem elérhető. Ellenőrizd, hogy a backend fut-e!");
    }

    if (response.status === 204) return null;

    const data = await response.json().catch(() => null);

    if (response.status === 401) {
        if (auth) {
            Auth.logout();
        }
        throw new Error(data?.error || "Helytelen email cím vagy jelszó");
    }

    if (!response.ok) {
        throw new Error(data?.error || "Sikertelen kérés");
    }

    return data;
}

function initBackgroundSlider() {
    const images = [
        "../kepek/kep1.jpg",
        "../kepek/kep2.jpg",
        "../kepek/kep3.jpg"
    ];

    let index = 0;
    const leftPanel = document.querySelector(".left-panel");
    if (!leftPanel) return;

    leftPanel.style.setProperty("--bg-image", `url('${images[0]}')`);

    setInterval(() => {
        index = (index + 1) % images.length;
        leftPanel.style.setProperty("--bg-image", `url('${images[index]}')`);
    }, 3000);
}

function initLoginPage() {
    if (Auth.isAuthenticated()) {
        window.location.href = CONFIG.HOME_PAGE;
        return;
    }

    const form = document.getElementById("loginForm");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const error = document.getElementById("errorMessage");
    const button = form.querySelector("button[type='submit']");

    function showError(msg) {
        error.textContent = msg;
        error.style.display = "block";
    }

    function hideError() {
        error.style.display = "none";
        error.textContent = "";
    }

    function validate(emailVal, passwordVal) {
        if (!emailVal) return "Az email cím megadása kötelező";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) return "Érvénytelen email cím";
        if (!passwordVal) return "A jelszó megadása kötelező";
        if (passwordVal.length < 6) return "A jelszónak legalább 6 karakter hosszúnak kell lennie";
        return null;
    }

    async function submit(e) {
        e.preventDefault();

        const emailVal = email.value.trim();
        const passwordVal = password.value;

        const validationError = validate(emailVal, passwordVal);
        if (validationError) {
            showError(validationError);
            return;
        }

        hideError();

        const originalText = button.textContent;
        button.disabled = true;
        button.textContent = "Logging in...";

        try {
            const data = await apiRequest(
                CONFIG.LOGIN_ENDPOINT,
                "POST",
                { email: emailVal, password: passwordVal },
                false
            );

            Auth.save(data);
            window.location.href = CONFIG.HOME_PAGE;

        } catch (err) {
            showError(err.message);
            button.disabled = false;
            button.textContent = originalText;
        }
    }

    form.addEventListener("submit", submit);
    email.addEventListener("input", hideError);
    password.addEventListener("input", hideError);
}

function setupTokenRefresh() {
    setInterval(async () => {
        if (!Auth.isAuthenticated()) return;

        try {
            const data = await apiRequest("/auth/refresh", "POST");
            if (data?.token) {
                localStorage.setItem("token", data.token);
            }
        } catch {
            Auth.logout();
        }
    }, CONFIG.TOKEN_REFRESH_INTERVAL * 60 * 1000);
}

document.addEventListener("DOMContentLoaded", () => {
    initBackgroundSlider();
    initLoginPage();
    setupTokenRefresh();
});