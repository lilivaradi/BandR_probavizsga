function loadSavedBands() {
    const savedBands = JSON.parse(localStorage.getItem('savedBands') || '[]');
    const container = document.getElementById('saved-bands-container');

    savedBands.forEach(band => {
        const bandCard = document.createElement('div');
        bandCard.className = 'text-box1';
        bandCard.innerHTML = `
                    <div class="content-wrapper">
                        <h2>${band.name}</h2>
                        <p>${band.description}</p>
                        <div class="extra-content">
                            <p>
                                You liked this band! They're looking for talented musicians to join their group.
                                Make sure to reach out to them and show your interest. This could be the perfect
                                opportunity to join a great band and create amazing music together.
                            </p>
                        </div>
                    </div>
                    <div class="img-wrapper">
                        <img src="${band.image}" alt="${band.name}">
                    </div>
                `;
        container.appendChild(bandCard);
    });
}

document.addEventListener('DOMContentLoaded', loadSavedBands);

const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const savedPosts = JSON.parse(localStorage.getItem('savedPosts') || '[]');
const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
const likeCounts = JSON.parse(localStorage.getItem('likeCounts') || '{"1": 42, "2": 28, "3": 15, "4": 33}');

document.querySelectorAll('.text-box1').forEach(post => {
    const postId = post.dataset.postId;
    const likeBtn = post.querySelector('.like-btn');
    const saveBtn = post.querySelector('.save-btn');
    const likeCount = post.querySelector('.like-count');

    likeCount.textContent = `${likeCounts[postId] || 0} Likes`;

    if (likedPosts.includes(postId)) {
        likeBtn.classList.add('liked');
        likeBtn.querySelector('ion-icon').setAttribute('name', 'heart');
    }

    if (savedPosts.includes(postId)) {
        saveBtn.classList.add('saved');
        saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark');
        saveBtn.querySelector('span').textContent = 'Saved';
    }

    likeBtn.addEventListener('click', (e) => {
        e.stopPropagation();

        if (likedPosts.includes(postId)) {
            const index = likedPosts.indexOf(postId);
            likedPosts.splice(index, 1);
            likeCounts[postId]--;
            likeBtn.classList.remove('liked');
            likeBtn.querySelector('ion-icon').setAttribute('name', 'heart-outline');
        } else {
            likedPosts.push(postId);
            likeCounts[postId]++;
            likeBtn.classList.add('liked');
            likeBtn.querySelector('ion-icon').setAttribute('name', 'heart');
        }

        likeCount.textContent = `${likeCounts[postId]} Likes`;
        localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
        localStorage.setItem('likeCounts', JSON.stringify(likeCounts));
    });

    saveBtn.addEventListener('click', (e) => {
        e.stopPropagation();

        if (savedPosts.includes(postId)) {
            const index = savedPosts.indexOf(postId);
            savedPosts.splice(index, 1);
            saveBtn.classList.remove('saved');
            saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark-outline');
            saveBtn.querySelector('span').textContent = 'Save';
        } else {
            savedPosts.push(postId);
            saveBtn.classList.add('saved');
            saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark');
            saveBtn.querySelector('span').textContent = 'Saved';
        }

        localStorage.setItem('savedPosts', JSON.stringify(savedPosts));
    });
});