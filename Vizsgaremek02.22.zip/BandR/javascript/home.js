const CONFIG = {
    BASE_URL: "http://localhost:8080/bandr/webresources",
    ENDPOINTS: {
        POSTS: "/posts",
        POST_LIKES: "/postlikes",
        SAVED: "/saved",
    },
    APP: {
        LOGIN_PAGE: "../html/login.html"
    }
};

const API = {
    async request(method, endpoint, body = null) {
        const headers = {
            "Content-Type": "application/json",
            ...Auth.getAuthHeader()
        };
        const options = { method, headers };
        if (body) options.body = JSON.stringify(body);

        const response = await fetch(`${CONFIG.BASE_URL}${endpoint}`, options);

        if (response.status === 401) {
            Auth.logout();
            throw new Error("Kérjük jelentkezz be újra.");
        }
        if (response.status === 204) return null;

        const data = await response.json().catch(() => null);
        if (!response.ok) throw new Error(data?.error || `HTTP hiba: ${response.status}`);
        return data;
    },
    get(endpoint) {
        return this.request("GET", endpoint);
    },

    post(endpoint, body) {
        return this.request("POST", endpoint, body);
    },

    delete(endpoint) {
        return this.request("DELETE", endpoint);
    }
};

const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const sidebarClose = document.querySelector('.sidebar-icon');

sidebarClose.addEventListener('click', (e) => {
    e.stopPropagation();
    sidebar.classList.remove('active');
    body.classList.remove('sidebar-open');
});

function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function createPostElement(post, liked = false, saved = false) {
    const div = document.createElement('div');
    div.classList.add('text-box1');
    div.dataset.postId = post.postId ?? post.id;

    const imgSrc = post.imageUrl || post.image || `../kepek/band1.jpg`;

    div.innerHTML = `
        <div class="text-box1-main">
            <div class="content-wrapper">
                <h2>${escapeHtml(post.title)}</h2>
                <p>${escapeHtml(post.description ?? post.content)}</p>
            </div>
            <div class="img-wrapper">
                <img src="${escapeHtml(imgSrc)}" alt="${escapeHtml(post.title)}"
                     onerror="this.src='../kepek/band1.jpg'">
            </div>
        </div>
        <div class="post-actions">
            <button class="action-btn like-btn ${liked ? 'liked' : ''}">
                <ion-icon name="${liked ? 'heart' : 'heart-outline'}"></ion-icon>
                <span class="like-count">${post.likeCount ?? 0} Likes</span>
            </button>
            <button class="action-btn save-btn ${saved ? 'saved' : ''}">
                <ion-icon name="${saved ? 'bookmark' : 'bookmark-outline'}"></ion-icon>
                <span>${saved ? 'Saved' : 'Save'}</span>
            </button>
            <button class="action-btn message-btn">
                <ion-icon name="chatbubble-outline"></ion-icon>
                <a href="../html/messages.html"><span>Message</span></a>
            </button>
        </div>
    `;

    return div;
}

async function handleLike(postId, btn) {
    const liked = btn._liked;
    const icon = btn.querySelector('ion-icon');
    const countSpan = btn.querySelector('.like-count');
    let count = parseInt(countSpan.textContent) || 0;

    if (liked) {
        icon.setAttribute('name', 'heart-outline');
        btn.classList.remove('liked');
        countSpan.textContent = `${Math.max(0, count - 1)} Likes`;
        btn._liked = false;
    } else {
        icon.setAttribute('name', 'heart');
        btn.classList.add('liked');
        countSpan.textContent = `${count + 1} Likes`;
        btn._liked = true;
    }

    try {
        if (liked) {
            await API.delete(`${CONFIG.ENDPOINTS.POST_LIKES}/${postId}`);
        } else {
            await API.post(CONFIG.ENDPOINTS.POST_LIKES, {
                postId: Number(postId),
                userId: Auth.getUserId()
            });
        }
    } catch (err) {
        console.error('Like hiba:', err);
        if (liked) {
            icon.setAttribute('name', 'heart');
            btn.classList.add('liked');
            countSpan.textContent = `${count} Likes`;
            btn._liked = true;
        } else {
            icon.setAttribute('name', 'heart-outline');
            btn.classList.remove('liked');
            countSpan.textContent = `${count} Likes`;
            btn._liked = false;
        }
    }
}

async function handleSave(postId, btn) {
    const saved = btn._saved;
    const icon = btn.querySelector('ion-icon');
    const textSpan = btn.querySelector('span');

    if (saved) {
        icon.setAttribute('name', 'bookmark-outline');
        btn.classList.remove('saved');
        textSpan.textContent = 'Save';
        btn._saved = false;
    } else {
        icon.setAttribute('name', 'bookmark');
        btn.classList.add('saved');
        textSpan.textContent = 'Saved';
        btn._saved = true;
    }

    try {
        if (saved) {
            await API.delete(`${CONFIG.ENDPOINTS.SAVED}/${postId}`);
        } else {
            await API.post(CONFIG.ENDPOINTS.SAVED, {
                postId: Number(postId),
                userId: Auth.getUserId()
            });
        }
    } catch (err) {
        console.error('Save hiba:', err);
        if (saved) {
            icon.setAttribute('name', 'bookmark');
            btn.classList.add('saved');
            textSpan.textContent = 'Saved';
            btn._saved = true;
        } else {
            icon.setAttribute('name', 'bookmark-outline');
            btn.classList.remove('saved');
            textSpan.textContent = 'Save';
            btn._saved = false;
        }
    }
}

function attachPostEvents(postEl) {
    const postId = postEl.dataset.postId;
    const likeBtn = postEl.querySelector('.like-btn');
    const saveBtn = postEl.querySelector('.save-btn');

    likeBtn._liked = likeBtn.classList.contains('liked');
    saveBtn._saved = saveBtn.classList.contains('saved');

    likeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        handleLike(postId, likeBtn);
    });

    saveBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        handleSave(postId, saveBtn);
    });
}

async function loadPosts() {
    const container = document.querySelector('.container-fluid');

    container.querySelectorAll('.text-box1').forEach(el => el.remove());

    const loader = document.createElement('div');
    loader.id = 'posts-loader';
    loader.style.cssText = 'text-align:center;padding:2rem;color:#aaa;font-size:1.1rem;';
    loader.textContent = 'Posztok betöltése...';
    container.appendChild(loader);

    try {
        const posts = await API.get(CONFIG.ENDPOINTS.POSTS);

        let likedIds = new Set();
        let savedIds = new Set();

        try {
            const userId = Auth.getUserId();
            if (userId) {
                const [likedData, savedData] = await Promise.all([
                    API.get(`${CONFIG.ENDPOINTS.POST_LIKES}?userId=${userId}`),
                    API.get(`${CONFIG.ENDPOINTS.SAVED}?userId=${userId}`)
                ]);
                if (Array.isArray(likedData))
                    likedIds = new Set(likedData.map(l => String(l.postId ?? l.id)));
                if (Array.isArray(savedData))
                    savedIds = new Set(savedData.map(s => String(s.postId ?? s.id)));
            }
        } catch (innerErr) {
            console.warn('Liked/saved listák nem elérhetők:', innerErr.message);
        }

        loader.remove();

        if (!Array.isArray(posts) || posts.length === 0) {
            const empty = document.createElement('p');
            empty.style.cssText = 'text-align:center;padding:2rem;color:#aaa;';
            empty.textContent = 'Még nincsenek posztok.';
            container.appendChild(empty);
            return;
        }

        posts.forEach(post => {
            const id = String(post.postId ?? post.id);
            const postEl = createPostElement(post, likedIds.has(id), savedIds.has(id));
            container.appendChild(postEl);
            attachPostEvents(postEl);
        });

    } catch (err) {
        loader.remove();
        console.error('Posztok betöltési hiba:', err);

        const errDiv = document.createElement('div');
        errDiv.style.cssText = 'text-align:center;padding:2rem;color:#e55;';
        errDiv.innerHTML = `
            <p>Nem sikerült betölteni</p>
            <small>${escapeHtml(err.message)}</small><br><br>
            <button onclick="loadPosts()" style="padding:.5rem 1.2rem;cursor:pointer;border-radius:6px;">
                Újrapróbálás
            </button>
        `;
        container.appendChild(errDiv);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (!Auth.isAuthenticated()) {
        window.location.href = CONFIG.APP.LOGIN_PAGE;
        return;
    }

    initSidebar();
    loadPosts();
});