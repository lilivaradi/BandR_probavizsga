document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');
    
    // Hide messages
    errorMessage.classList.remove('show');
    successMessage.classList.remove('show');
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!emailRegex.test(email)) {
        errorMessage.textContent = 'Kérlek adj meg egy érvényes email címet!';
        errorMessage.classList.add('show');
        return;
    }
    
    // TODO: Replace with actual API call to check if email exists
    // For now, simulate API call
    setTimeout(() => {
        // Simulate checking if email exists in database
        const emailExists = true; // This should come from your backend
        
        if (emailExists) {
            successMessage.classList.add('show');
            
            // Redirect to login page after 3 seconds
            setTimeout(() => {
                window.location.href = '../html/login.html';
            }, 3000);
        } else {
            errorMessage.classList.add('show');
        }
    }, 500);
});