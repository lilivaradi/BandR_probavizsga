const settingsBtn = document.getElementById('settings-btn');
const sidebar = document.getElementById('sidebar');
const closeSidebar = document.getElementById('close-sidebar');

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    document.body.classList.toggle('sidebar-open');
});

closeSidebar.addEventListener('click', () => {
    sidebar.classList.remove('active');
    document.body.classList.remove('sidebar-open');
});

document.addEventListener('click', (e) => {
    if (!sidebar.contains(e.target) && !settingsBtn.contains(e.target)) {
        sidebar.classList.remove('active');
        document.body.classList.remove('sidebar-open');
    }
});

const menuItems = document.querySelectorAll('.admin-menu ul li');
menuItems.forEach(item => {
    item.addEventListener('click', function () {
        menuItems.forEach(i => i.classList.remove('active'));
        this.classList.add('active');
    });
});

document.getElementById('user-search').addEventListener('input', function () {
    const term = this.value.toLowerCase();
    document.querySelectorAll('#users-table tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
    });
});

document.querySelectorAll('.row-btn-del').forEach(btn => {
    btn.addEventListener('click', function () {
        const row = this.closest('tr');
        const name = row.querySelector('.user-cell').textContent.trim();
        if (confirm('Biztosan törölni szeretnéd: ' + name + '?')) {
            row.style.transition = 'opacity 0.4s';
            row.style.opacity = '0';
            setTimeout(() => row.remove(), 400);
        }
    });
});