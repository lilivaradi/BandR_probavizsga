document.addEventListener("DOMContentLoaded", () => {
    const conversationItems = document.querySelectorAll(".conversation-item");
    const chatMessages = document.getElementById("chatMessages");
    const messageInput = document.getElementById("messageInput");
    const sendBtn = document.getElementById("sendBtn");

    const chatHeaderName = document.querySelector(".chat-header-info h2");
    const chatHeaderAvatar = document.querySelector(".chat-header-avatar");
    const statusDot = document.getElementById("statusDot");
    const statusText = document.getElementById("statusText");

    let activeUserId = "1";

    const userStatus = {
        1: "online",
        2: "offline",
        3: "online",
        4: "offline",
        5: "offline"
    };

    const messages = {
        1: [...chatMessages.innerHTML],
        2: [],
        3: [],
        4: [],
        5: []
    };

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function updateStatus(userId) {
        if (userStatus[userId] === "online") {
            statusDot.style.color = "#4cd137";
            statusText.textContent = "Online";
        } else {
            statusDot.style.color = "#aaa";
            statusText.textContent = "Offline";
        }
    }

    function renderMessages(userId) {
        chatMessages.innerHTML = messages[userId].join("");
        scrollToBottom();
        updateStatus(userId);
    }

    function sendMessage() {
        const text = messageInput.value.trim();
        if (!text) return;

        const time = new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });

        const messageHTML = `
            <div class="message sent">
                <div class="message-avatar">ME</div>
                <div class="message-content">
                    <div class="message-bubble">${text}</div>
                    <div class="message-time">${time}</div>
                </div>
            </div>
        `;

        messages[activeUserId].push(messageHTML);
        renderMessages(activeUserId);
        messageInput.value = "";

        setTimeout(() => receiveMessage(activeUserId), 1500);
    }

    function receiveMessage(userId) {
        const time = new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });

        const replyHTML = `
            <div class="message">
                <div class="message-avatar">${chatHeaderAvatar.textContent}</div>
                <div class="message-content">
                    <div class="message-bubble">Sounds good! 👍</div>
                    <div class="message-time">${time}</div>
                </div>
            </div>
        `;

        messages[userId].push(replyHTML);

        if (userId === activeUserId) {
            renderMessages(userId);
        } else {
            showNotification(userId);
        }
    }

    function showNotification(userId) {
        const convo = document.querySelector(
            `.conversation-item[data-user-id="${userId}"]`
        );

        if (!convo.querySelector(".unread-badge")) {
            const badge = document.createElement("div");
            badge.className = "unread-badge";
            badge.textContent = "1";
            convo.appendChild(badge);
        }

        convo.querySelector(".conversation-preview").textContent =
            "New message…";
    }

    sendBtn.addEventListener("click", sendMessage);

    messageInput.addEventListener("keypress", e => {
        if (e.key === "Enter") sendMessage();
    });

    conversationItems.forEach(item => {
        item.addEventListener("click", () => {
            conversationItems.forEach(i => i.classList.remove("active"));
            item.classList.add("active");

            activeUserId = item.dataset.userId;

            chatHeaderName.textContent =
                item.querySelector(".conversation-name").textContent;
            chatHeaderAvatar.textContent =
                item.querySelector(".conversation-avatar").textContent;

            item.querySelector(".unread-badge")?.remove();

            renderMessages(activeUserId);
        });
    });

    renderMessages(activeUserId);
});
