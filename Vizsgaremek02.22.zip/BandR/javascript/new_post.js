const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const sidebarClose = document.querySelector('.sidebar-icon');
sidebarClose.addEventListener('click', (e) => {
    e.stopPropagation();
    sidebar.classList.remove('active');
    body.classList.remove('sidebar-open');
});

const titleInput = document.getElementById('postTitle');
const descriptionInput = document.getElementById('postDescription');
const detailsInput = document.getElementById('postDetails');
const imageInput = document.getElementById('postImage');

const previewTitle = document.getElementById('previewTitle');
const previewDescription = document.getElementById('previewDescription');
const previewExtra = document.getElementById('previewExtra');
const previewImage = document.getElementById('previewImage');

titleInput.addEventListener('input', (e) => {
    previewTitle.textContent = e.target.value || 'A poszt címe itt jelenik meg';
});

descriptionInput.addEventListener('input', (e) => {
    previewDescription.textContent = e.target.value || 'A rövid leírás itt lesz látható...';
});

detailsInput.addEventListener('input', (e) => {
    previewExtra.querySelector('p').textContent = e.target.value || 'A részletes leírás tartalma...';
});

imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            previewImage.src = event.target.result;

            const preview = document.getElementById('imagePreview');
            preview.innerHTML = `<img src="${event.target.result}" alt="preview">`;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});

document.getElementById('newPostForm').addEventListener('submit', (e) => {
    e.preventDefault();

    alert('Poszt sikeresen létrehozva! (Ez csak egy demo)');
});

const previewBox = document.querySelector('.text-box1-preview');
previewBox.addEventListener('click', () => {
    previewBox.classList.toggle('expanded');
});