const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const textBoxes = document.querySelectorAll('.text-box1');

textBoxes.forEach(box => {
    box.addEventListener('click', () => {
        textBoxes.forEach(otherBox => {
            if (otherBox !== box) {
                otherBox.classList.remove('expanded');
            }
        });

        box.classList.toggle('expanded');
    });
});

const sidebarClose = document.querySelector('.sidebar-icon');

sidebarClose.addEventListener('click', (e) => {
    e.stopPropagation();
    sidebar.classList.remove('active');
    body.classList.remove('sidebar-open');
});