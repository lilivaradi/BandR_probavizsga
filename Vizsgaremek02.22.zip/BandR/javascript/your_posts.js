const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settings-btn');
const body = document.body;

settingsBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    body.classList.toggle('sidebar-open');
});

body.addEventListener('click', (e) => {
    if (body.classList.contains('sidebar-open') && !sidebar.contains(e.target) && e.target !== settingsBtn) {
        sidebar.classList.remove('active');
        body.classList.remove('sidebar-open');
    }
});

const textBoxes = document.querySelectorAll('.text-box1');

textBoxes.forEach(box => {
    box.addEventListener('click', () => {
        textBoxes.forEach(otherBox => {
            if (otherBox !== box) {
                otherBox.classList.remove('expanded');
            }
        });

        box.classList.toggle('expanded');
    });
});

const sidebarClose = document.querySelector('.sidebar-icon');

sidebarClose.addEventListener('click', (e) => {
    e.stopPropagation();
    sidebar.classList.remove('active');
    body.classList.remove('sidebar-open');
});

// Like and Save functionality
const savedPosts = JSON.parse(localStorage.getItem('savedPosts') || '[]');
const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
const likeCounts = JSON.parse(localStorage.getItem('likeCounts') || '{"1": 42, "2": 28, "3": 15, "4": 33}');

// Initialize button states
document.querySelectorAll('.text-box1').forEach(post => {
    const postId = post.dataset.postId;
    const likeBtn = post.querySelector('.like-btn');
    const saveBtn = post.querySelector('.save-btn');
    const likeCount = post.querySelector('.like-count');

    // Set initial like count
    likeCount.textContent = `${likeCounts[postId] || 0} Likes`;

    // Check if already liked
    if (likedPosts.includes(postId)) {
        likeBtn.classList.add('liked');
        likeBtn.querySelector('ion-icon').setAttribute('name', 'heart');
    }

    // Check if already saved
    if (savedPosts.includes(postId)) {
        saveBtn.classList.add('saved');
        saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark');
        saveBtn.querySelector('span').textContent = 'Saved';
    }

    // Like button click
    likeBtn.addEventListener('click', (e) => {
        e.stopPropagation();

        if (likedPosts.includes(postId)) {
            // Unlike
            const index = likedPosts.indexOf(postId);
            likedPosts.splice(index, 1);
            likeCounts[postId]--;
            likeBtn.classList.remove('liked');
            likeBtn.querySelector('ion-icon').setAttribute('name', 'heart-outline');
        } else {
            // Like
            likedPosts.push(postId);
            likeCounts[postId]++;
            likeBtn.classList.add('liked');
            likeBtn.querySelector('ion-icon').setAttribute('name', 'heart');
        }

        likeCount.textContent = `${likeCounts[postId]} Likes`;
        localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
        localStorage.setItem('likeCounts', JSON.stringify(likeCounts));
    });

    // Save button click
    saveBtn.addEventListener('click', (e) => {
        e.stopPropagation();

        if (savedPosts.includes(postId)) {
            // Unsave
            const index = savedPosts.indexOf(postId);
            savedPosts.splice(index, 1);
            saveBtn.classList.remove('saved');
            saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark-outline');
            saveBtn.querySelector('span').textContent = 'Save';
        } else {
            // Save
            savedPosts.push(postId);
            saveBtn.classList.add('saved');
            saveBtn.querySelector('ion-icon').setAttribute('name', 'bookmark');
            saveBtn.querySelector('span').textContent = 'Saved';
        }

        localStorage.setItem('savedPosts', JSON.stringify(savedPosts));
    });
});